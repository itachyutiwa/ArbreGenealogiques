import java.io.*;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

public class Main {

    static void routeur(String choix,Arbre arbre){
       Scanner sc = new Scanner(System.in);
         switch (choix){
             case "0":{
                 ecriture(arbre);
                 System.out.println("\t\t|Merci et à bientot...");
             };break;
             // le choix pour creation d'une personne
             case "1":{
                 System.out.println("\t\t|vous avez choisi l'option 1) Construire nouveau Arbre");
                 creation(arbre);
                 ecriture(arbre);
                 routeur2(arbre);
             };break;
             case "3":{
                 System.out.println("\t\t|vous avez choisi l'option 3) Informations sur une personnes");
                 Personne p;
                 String reponse1 = "O";
                 while (reponse1.equalsIgnoreCase("O")) {
                     p = arbre.selectionPersonne();System.out.println("\t\t|");
                     if (p!=null){
                         arbre.menuPersonne(p);
                         System.out.print("\t\t| voulez vous continuer avec une autre personne ? : O/N : ");
                         reponse1 = sc.nextLine();
                     }else{
                         System.out.print("\t\t| personne introuvable, voulez vous continuer ? : O/N : ");
                         reponse1 = sc.nextLine();
                     }

                 }
                 routeur2(arbre);

             }break;
             case "2":{
                 System.out.println("\t\t|vous avez choisi l'option 2) Continuer arbre existant");
                System.out.println("\t\t|Pour continuer un arbre genealogique vous allez fournir le nom de la famille :");
                 String reponse1 = "O";Personne p;
                     while (reponse1.equalsIgnoreCase("O")) {
                          p = arbre.ancetreParNomFamille();System.out.println("\t\t|");
                         if (p!=null){
                             clearConsole();
                             Menu.header();
                             System.out.println("\t\t|Arbre genealogique de l'ancetre ...");
                             arbre.parcourAbre(p);System.out.println("\t\t");
                              p = arbre.selectionPersonneParID();
                             if(p!=null){
                                 System.out.print("\t\t| vous essayez d'ajouter des enfants pour ");
                                 p.affiche();
                                 p.demandeEnfant(arbre);
                                 p.reaffecteID();
                                 System.out.print("\t\t| voulez vous continuer un arbre  : O/N : ");
                                 reponse1 = sc.nextLine();
                             }else{
                                 System.out.print("\t\t| parent introuvable,car mauvais ID saisi. voulez vous continuer un arbre  : O/N : ");
                                 reponse1 = sc.nextLine();
                             }
                         }else{
                             System.out.print("\t\t| parent introuvable, voulez vous continuer un arbre  : O/N : ");
                             reponse1 = sc.nextLine();
                         }
                    }
                    ecriture(arbre);routeur2(arbre);
             }break;
             case "4":{
                 System.out.println("\t\t|vous avez choisi l'option 4) Afficher arbre");
                 System.out.println("\t\t|Pour afficher un arbre genealogique vous allez fournir le nom de la famille :");
                 String reponse1 = "O";Personne p;
                 while (reponse1.equalsIgnoreCase("O")) {
                     p = arbre.ancetreParNomFamille();System.out.println("\t\t|");
                     if (p!=null){
                         clearConsole();
                         Menu.header();
                         System.out.println("\t\t|Arbre genealogique de l'ancetre ...");
                         arbre.parcourAbre(p);System.out.println("\t\t");
                         System.out.print("\t\t| voulez-vous continuer d'afficher d'autres arbre ?  : O/N : ");
                         reponse1 = sc.nextLine();
                     }else{
                         System.out.print("\t\t| parent introuvable, voulez vous continuer ? : O/N : ");
                         reponse1 = sc.nextLine();
                     }
                 }
                 routeur2(arbre);
             }break;
         }
   }
    static Arbre lecture(){
        // Deserelialisation
        Arbre arbre = new Arbre();
        try {
            FileInputStream fis = new FileInputStream("Arbre1.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
             arbre = (Arbre) ois.readObject();
            fis.close();
        }
        catch(FileNotFoundException e) { System.out.println("\t\t|fichier introuvale pour deserialiser "); }
        catch(IOException e) {  System.out.println("\t\t|probleme de lecture");}
        catch(ClassNotFoundException e) { System.out.println("\t\t|probleme de classe"); }
        return arbre;
    }
    static void ecriture(Arbre arbre){
        // Serelialisation
        try {
            FileOutputStream fos = new FileOutputStream("Arbre1.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(arbre);
            oos.close();}
        catch(FileNotFoundException e) { System.out.println("\t\t|fichier introuvale pour serialiser"); }
        catch(IOException e) { System.out.println("\t\t|probleme d'ecriture"); }
    }
    static void creation(Arbre arbre){
        Personne p = new Personne();
        if(arbre.personnes.isEmpty()){
            int id = p.get_globalID();
            ecrireID(++id);
        }else {
            int globalID=0;
            for (Personne k:arbre.personnes){
                if(k.get_globalID()>globalID){
                    globalID = k.get_globalID();
                }
            }
            ecrireID(globalID);
            p.set_id(lireID());
            p.set_globalID(Integer.parseInt(lireID()));
            int id = Integer.parseInt(p.get_id());
            ecrireID(++id);
        }
        p.creation();
        arbre.ajouterPersonne(p);
        p.demandeEnfant(arbre);
        arbre.parcourAbre(p);
        System.out.println("\t\t| Enregistré avec succès ...");
    }
    static  void routeur2(Arbre arbre){
        Scanner sc = new Scanner(System.in);
        String g = "";
        while (!g.equalsIgnoreCase("0") && !g.equalsIgnoreCase("00")) {
            System.out.println("\t\t|");
            System.out.println("\t\t|0) -  Quitter :");
            System.out.println("\t\t|00) -  Menu principal :");
            System.out.print("\t\t| taper 0 ou 00 : ");
            g = sc.nextLine();
        }
        if (g.equalsIgnoreCase("00")){
            clearConsole();
            arbre = lecture();
            String choix = Menu.body(arbre);
            routeur(choix,arbre);
        }

        else{
            ecriture(arbre);
            System.out.println("\t\t|Merci et à bientot...");
        }

    }

    public static void main(String[] args) {
        Arbre arbre = lecture();
        String choix = Menu.body(arbre);
        routeur(choix,arbre);
    }


    public final static void clearConsole(){
        //Clears Screen in java
        try {
            if (System.getProperty("os.name").contains("Windows"))
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
                Runtime.getRuntime().exec("clear");
        } catch (IOException | InterruptedException ex) {}

    }



    public static void ecrireID(int i){
 String globalID = ""+i;
        // Serelialisation
        try {
            FileOutputStream fos = new FileOutputStream("globalID.dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(globalID);
            oos.close();}
        catch(FileNotFoundException e) { System.out.println("\t\t|fichier introuvale pour serialiser"); }
        catch(IOException e) { System.out.println("\t\t|probleme d'ecriture"); }

    }


    public static String lireID(){
  // Deserelialisation
        String globalID="0";
        try {
            FileInputStream fis = new FileInputStream("globalID.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            globalID = (String) ois.readObject();
            fis.close();
        }
        catch(FileNotFoundException e) { System.out.println("\t\t|fichier introuvale pour deserialiser "); }
        catch(IOException e) {  System.out.println("\t\t|probleme de lecture");}
        catch(ClassNotFoundException e) { System.out.println("\t\t|probleme de classe"); }
        return globalID;
    }
}
