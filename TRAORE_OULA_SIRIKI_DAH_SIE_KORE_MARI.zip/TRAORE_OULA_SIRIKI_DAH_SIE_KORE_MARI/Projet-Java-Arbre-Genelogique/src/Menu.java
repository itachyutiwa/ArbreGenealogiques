import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Scanner;

public class Menu {


    static public void header(){
        System.out.println("\t\t+------------------------------------------------------------------------------------------------+");
        System.out.println("\t\t|                                 ___________________________________                            |");
        System.out.println("\t\t|                                 | APPLICATION D'ARBRE GENEALOGIQUE |                           |");
        System.out.println("\t\t|                                 -----------------------------------                            |");
        System.out.println("\t\t+------------------------------------------------------------------------------------------------+");
        System.out.println("\t\t|Bienvenue sur l'application de gestion d'arbre genelogique de personnes, nous presentons ici :  |");
        System.out.println("\t\t|                                                                                                |");
    }
    static public String body(Arbre arb2){
        header();
        Scanner sc = new Scanner(System.in);
        ArrayList<String> famille  = new ArrayList<>();
        String options[] ={"1) Construire nouveau Arbre         ","2) Continuer arbre existant         ","3) Informations sur une personne   ","4) Afficher arbre                    ","0) Quitter l'application              "};
       for (Personne p: arb2.personnes){
               if(ElementExisteDansListe(famille,p.get_nom())==false)
                   famille.add(p.get_nom());
           }

        System.out.println("\t\t|Options :                            \t\t\t|Noms de Fammilles existantes\t\t ");
        System.out.println("\t\t|-------------------------------------------------------------------------------------------------");
        if(options.length>famille.size()){
            for (int i=0;i<options.length;i++){
                if(i<famille.size()){
                    System.out.print("\t\t|"+options[i]+"\t\t\t|");
                    System.out.println(famille.get(i));
                }else{
                    System.out.print("\t\t|"+options[i]+"\t\t\t|");
                    System.out.println("");
                }

            }
        }else{
            for (int i=0;i<famille.size();i++){
                if(i<options.length){
                    System.out.print("\t\t|"+options[i]+"\t\t\t|");
                    System.out.println(famille.get(i));
                }else{
                    System.out.print("\t\t|                                    \t\t\t|");
                    System.out.println(famille.get(i));
                }

            }
        }

        System.out.println("\t\t|");
        String choix = "";
        while (!choix.equalsIgnoreCase("1") && !choix.equalsIgnoreCase("2") && !choix.equalsIgnoreCase("3") && !choix.equalsIgnoreCase("0") && !choix.equalsIgnoreCase("4")){
            System.out.print("\t\t|choisir une option : ");
            choix = sc.nextLine();
        }
    return choix;
    }
    static public boolean ElementExisteDansListe(ArrayList<String> l, String s){
        for (String str: l){
            if(str.equalsIgnoreCase(s))
                return true;
        }
        return false;
    }
}
