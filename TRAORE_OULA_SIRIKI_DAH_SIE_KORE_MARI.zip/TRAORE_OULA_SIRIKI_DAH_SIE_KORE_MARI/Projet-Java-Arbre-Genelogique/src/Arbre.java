import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class Arbre implements Serializable {
    public ArrayList<Personne> personnes;
    Arbre(){
        personnes = new ArrayList<>();
    }

    public void ajouterPersonne(Personne p){
        personnes.add(p);
    }

    // fonction qui permet de retrouver une personne dans l'arbre genealogique
    public Personne selectionPersonne(){
        Scanner sc = new Scanner(System.in);
        System.out.print("\t\t| Entrer le nom de la personne : ");
        String nom = sc.nextLine();
        System.out.print("\t\t| Entrer le prenoms de la personne : ");
        String prenoms = sc.nextLine();
        Personne personneSelectionne = null;
        ArrayList<Personne> persons = new ArrayList<>();
        for (Personne p: this.personnes){
            if(p.get_nom().equalsIgnoreCase(nom) && p.get_prenoms().equalsIgnoreCase(prenoms)){
                persons.add(p);
            }
        }
        if (persons.isEmpty()){
            return personneSelectionne;
        }if (persons.size()==1){
            return persons.get(0);
        }else{
            System.out.println("\t\t|voici les personnes retrouvées : ");
            afficheInfoPersonnes(persons);
            System.out.print("\t\t|veillez saisir l'ID correspondant : ");
            String ID = sc.nextLine();
            for (Personne j:persons){
                if(j.get_id().equalsIgnoreCase(ID)){
                    personneSelectionne = j;
                }
            }

            return personneSelectionne;
        }
    }

    public void afficheInfoPersonnes(ArrayList<Personne> person){
        for (Personne p: person)
            p.affiche();
    }

    // fonction de parcours d'arbre genealogique d'un individus
    public void parcourAbre(Personne p){
        System.out.print("```\t\t|");
        for (int i=0; i<p.nombreAscendants();i++)
            System.out.print("~~~~~~");
        p.affiche();
        for(Personne p1: p.get_enfants()){
            parcourAbre(p1);

         }

    }

    // fonction qui affiche les descendant d'une personnes
    public void afficheDescendants(Personne p){
        if(p !=null)
        parcourAbre(p);
        else
            System.out.println("\t\t|personne introuvable ");
    }

    // fonction qui affiches les ascendants d'une personne
    public void ascendantPersonne(Personne p1){
        if(p1.get_parent()!=null){
            Personne p = p1;
            while (p.get_parent()!=null){
                p.get_parent().affichePourAscendant();
                p = p.get_parent();
            }
        }else System.out.println("`\t\tPas d'ascendant trouvé...");

    }

    // fonction d'affichage des cousins d'une personnes
    public void cousin(Personne p1){
        if(p1.get_parent()!=null){
            if(p1.get_parent().get_parent()!=null && p1.get_parent().get_parent().get_enfants().size()>1){
                for (Personne p: p1.get_parent().get_parent().get_enfants()){
                    if(p !=p1.get_parent())
                        p.afficheEnfants();
                }
            }else System.out.println("\t\t|Cette personne n'a pas de cousins . ");

        }else
            System.out.println("\t\t|Cette personne n'a pas de cousins . ");
    }

    // fonction d'affichage les freres et soeurs d'une personnes
    public void frereSoeur(Personne p1){
        if(p1.get_parent() !=null){
            if (  p1.get_parent().get_enfants().size()>1){
                for (Personne p: p1.get_parent().get_enfants()){
                    if(p != p1)
                        p.affiche2();
            }
        }else
                System.out.println("\t\t|Cette personne n'a pas de frere et soeurs . ");
        }else
            System.out.println("\t\t|Cette personne n'a pas de frere et soeurs . ");
    }

    // fonction d'affichage l'ainé d'une personnes
    public void aine(Personne p1){
        if(p1.get_parent() !=null && !p1.get_parent().get_enfants().isEmpty()){
                if(p1.get_parent().get_enfants().get(0) != p1){
                    System.out.println("\t\t|l'ainé de "+p1.get_nom()+" "+p1.get_prenoms()+" est : ");
                    p1.get_parent().get_enfants().get(0).affiche2();
                }

                else
                    System.out.println("\t\t|Cette personne est lui-meme l'ainé de la famille .");

        }else
            System.out.println("\t\t|Cette personne n'a pas d'ainé. ");
    }

    public Personne ancetreParNomFamille(){
        Scanner sc = new Scanner(System.in);
        System.out.print("\t\t| Entrer le nom de la famille : ");
        String famille = sc.nextLine();
        Personne ancetre  = null;
        for (Personne p : personnes){
            if(p.get_nom().equalsIgnoreCase(famille)){
                ancetre = p;
                break;
            }
        }
        if (ancetre==null){
            return ancetre;
        }else
        return  ancetre.renvoiAncetre();
    }

    // fonction qui permet de retrouver une personne dans l'arbre genealogique
    public Personne selectionPersonneParID(){
        Scanner sc = new Scanner(System.in);
        System.out.print("\t\t| Entrer l'ID d'une personne pour ajouter ses enfants : ");
        String id = sc.nextLine();
        Personne PersonneSelectionne = null;
        for (Personne p: personnes){
            if(p.get_id().equalsIgnoreCase(id)){
                PersonneSelectionne= p;
                break;
            }

        }
        return PersonneSelectionne;
    }

    //fonction qui affiche les oncles ou tantes d'une personne
    public void oncles(Personne p){
        if(p.get_parent()!=null){
            if(p.get_parent().get_parent()!=null){
                if(p.get_parent().get_parent().get_enfants().size()>1){
                    for (Personne p1 : p.get_parent().get_parent().get_enfants()){
                        if (p1!=p.get_parent())
                            p1.affiche2();
                    }
                }else System.out.println("\t\t|cette personne n'a pas d'oncle ou de tante . ");
            }else System.out.println("\t\t|cette personne n'a pas d'oncle ou de tante . ");
        }else System.out.println("\t\t|cette personne n'a pas d'oncle ou de tante . ");
    }

    //fonction qui affiche le pere d'une personne
    public void pere(Personne p){
        if(p.get_parent()!=null){
            System.out.print("\t\t|Son pere est : ");
            p.get_parent().affiche2();
        }else System.out.println("\t\t|cette personne n'a pas de père");
    }

    //fonction qui affiche les neveux et niece d'une personne
    public void neveuxNieces(Personne p){
        if(p.get_parent()!=null){
            if(p.get_parent().get_enfants().size()>1){
                System.out.println("\t\t| voici ses neveux/nices : ");
                for (Personne p1 : p.get_parent().get_enfants()){
                    if(p1!=p){
                        p1.afficheEnfants();
                    }
                }
            }else System.out.println("\t\t|cette personne n'a pas de neveux et nieces");
        }else System.out.println("\t\t|cette personne n'a pas de neveux et nieces");
    }

    //Menu d'une personne
    public void menuPersonne(Personne p){
        headerPersonne(p);
        Scanner sc = new Scanner(System.in);
        String choix = "1";
        while (choix.equalsIgnoreCase("1") || choix.equalsIgnoreCase("2")
                || choix.equalsIgnoreCase("3") || choix.equalsIgnoreCase("0")
                || choix.equalsIgnoreCase("4") || choix.equalsIgnoreCase("5")||
                choix.equalsIgnoreCase("6") || choix.equalsIgnoreCase("7")||
                choix.equalsIgnoreCase("8")|| choix.equalsIgnoreCase("9")||
                choix.equalsIgnoreCase("10")|| choix.equalsIgnoreCase("11")||
                choix.equalsIgnoreCase("12")|| choix.equalsIgnoreCase("13")){

            System.out.print("\t\t|choisir une option : ");
            choix = sc.nextLine();
            System.out.println("\t\t|");
            switch (choix){
                case "1":{
                    Main.clearConsole();
                    headerPersonne(p);
                    System.out.println("\t\t|vous avez choisi l'option 1)Ses ascendants ");
                    System.out.println("\t\t| Les ascendants dans l'ordre croisant :");
                    ascendantPersonne(p);
                    System.out.println("\t\t|");
                };break;
                case "2":{
                    Main.clearConsole();
                    headerPersonne(p);
                    System.out.println("\t\t|vous avez choisi l'option2)Ses enfants ");
                    System.out.println("\t\t| Les enfants de l'ainé au plus petit :");
                    System.out.println("\t\t|");
                    p.afficheEnfants();
                    System.out.println("\t\t|");
                };break;
                case "3":{
                    Main.clearConsole();
                    headerPersonne(p);
                    System.out.println("\t\t|vous avez choisi l'option 3)Ses descendants ");
                    System.out.println("\t\t| Voici son arbre genealogique...");
                    parcourAbre(p);
                    System.out.println("\t\t|");
                };break;
                case "4":{
                    Main.clearConsole();
                    headerPersonne(p);
                    System.out.println("\t\t|vous avez choisi l'option 4)Son frere ou soeur ainé ");
                    System.out.println("\t\t| Son frere ou soeur ainé est : ");
                    aine(p);
                    System.out.println("\t\t|");
                };break;
                case "5":{
                    Main.clearConsole();
                    headerPersonne(p);
                    System.out.println("\t\t|vous avez choisi l'option 5)Ses oncles ");
                    System.out.println("\t\t| Ses oncles ou tantes sont : ");
                    oncles(p);
                    System.out.println("\t\t|");
                };break;
                case "6":{
                    Main.clearConsole();
                    headerPersonne(p);
                    System.out.println("\t\t|vous avez choisi l'option 6)Ses cousins ");
                    System.out.println("\t\t| Ses cousins sont : ");
                    cousin(p);
                    System.out.println("\t\t|");
                };break;
                case "7":{
                    System.out.println("\t\t|vous avez choisi l'option 7)Modifier son nom  ");
                    System.out.print("\t\t|voulez-vous vraiment modifier le nom ? O/N : ");
                    String reponse = sc.nextLine();
                    if (reponse.equalsIgnoreCase("O")){
                        System.out.println("\t\t|le nom actuel est "+p.get_nom());
                        System.out.print("\t\t|saison le nouveau nom : ");
                        String nom = sc.nextLine();
                        p.set_nom(nom);
                        Main.ecriture(this);
                        Main.clearConsole();
                        headerPersonne(p);
                     System.out.println("\t\t|Modifié avec succès ...");

                }else System.out.println("\t\t|Modification annulée ...");
                };break;
                case "8":{
                    System.out.println("\t\t|vous avez choisi l'option 8)Modifier son prenoms  ");
                    System.out.print("\t\t|voulez-vous vraiment modifier le prenoms ? O/N : ");
                    String reponse = sc.nextLine();
                    if (reponse.equalsIgnoreCase("O")){
                        System.out.println("\t\t|le prenoms actuel est "+p.get_prenoms());
                        System.out.print("\t\t|saison le nouveau prenoms : ");
                        String nom = sc.nextLine();
                        p.set_prenoms(nom);
                        Main.ecriture(this);
                        Main.clearConsole();
                        headerPersonne(p);
                        System.out.println("\t\t|Modifié avec succès ...");

                }else System.out.println("\t\t|Modification annulée ...");
                };break;
                case "9":{
                    System.out.println("\t\t|vous avez choisi l'option 9)Modifier genre  ");
                    System.out.print("\t\t|voulez-vous vraiment modifier le genre ? O/N : ");
                    String reponse = sc.nextLine();
                    if (reponse.equalsIgnoreCase("O")){
                        System.out.println("\t\t|le genre actuel est "+p.get_sexe());
                        System.out.println("\t\t|saison le nouveau genre : ");
                        char genre = Personne.genre();
                        p.set_sexe(genre);
                        Main.ecriture(this);
                        Main.clearConsole();
                        headerPersonne(p);
                        System.out.println("\t\t|Modifié avec succès ...");

                    }else System.out.println("\t\t|Modification annulée ...");
                };break;
                case "10":{
                    Main.clearConsole();
                    headerPersonne(p);
                    System.out.println("\t\t|vous avez choisi l'option 10)Ses freres et soeurs  ");
                    System.out.println("\t\t| Ses freres et soeurs sont : ");
                    frereSoeur(p);
                    System.out.println("\t\t|");
                };break;
                case "11":{
                    System.out.println("\t\t|vous avez choisi l'option 11)Son père ");
                    pere(p);
                };break;
                case "12":{
                    Main.clearConsole();
                    headerPersonne(p);
                    System.out.println("\t\t|vous avez choisi l'option 12)Ses neveux et nieces ");
                    neveuxNieces(p);
                    System.out.println("\t\t|");
                };break;
                case "13":{
                    Main.clearConsole();
                    headerPersonne(p);
                    System.out.println("\t\t|vous avez choisi l'option 13)Ajouter des enfants ");
                    p.demandeEnfant(this);
                    p.reaffecteID();
                    personnes.addAll(p.get_enfants());
                    Main.ecriture(this);
                    System.out.println("\t\t|");
                };break;
                case "0":{
                    choix="";
                };break;
            }

        }

}

    public void headerPersonne(Personne p){
    Main.clearConsole();
    Menu.header();
    System.out.println("\t\t|                 \t\t\tMenu personnel de : "+p.get_id().toUpperCase()+", "+p.get_nom().toUpperCase()+" "+p.get_prenoms().toUpperCase()+", "+p.get_sexe()+", "+p.get_dataNaissance()+"\t\t\t\t            |");

    System.out.println("\t\t|-------------------------------------------------------------------------------------------------");
    System.out.println("\t\t|1)Ses ascendants                        |2)Ses enfants                  |3)Ses descendants      |");
    System.out.println("\t\t|4)Son frere ou soeur ainé               |5)Ses oncles                   |6)Ses cousins          |");
    System.out.println("\t\t|7)Modifier son nom                      |8)Modifier son prenom          |9)Modifier genre       |");
    System.out.println("\t\t|10)Ses freres et soeurs                 |11)Son père                    |12)Ses neveux et nieces|");
    System.out.println("\t\t|13)Ajouter des enfants                                  0-Taper 0 pour quitter ce menu          |");

    System.out.println("\t\t|");

    }


}

