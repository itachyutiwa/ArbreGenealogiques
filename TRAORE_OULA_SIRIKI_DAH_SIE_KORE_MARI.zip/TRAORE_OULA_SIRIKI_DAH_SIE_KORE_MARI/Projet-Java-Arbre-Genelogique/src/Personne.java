import com.sun.prism.paint.Color;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Personne implements Serializable {
    public  int globalID;
    private String id;
    private String nom;
    private String prenoms;
    private char sexe;
    private String dateNaissance;
    private Personne parent = null;
    private ArrayList<Personne> enfants;


    //setteur et getteur de ID
    public void set_id(String id) {
        this.id ="0"+id;
    }

public void set_idEnfant(String id){
    this.id =id;
}

    public int get_globalID(){
        return globalID;
    }

    public void set_globalID(int i){
        globalID = i;
    }

    public String get_id() {
        return id;
    }

    //setteur et getteur de nom
    public void set_nom(String nom) {
        this.nom = nom;
    }

    public String get_nom() {
        return nom;
    }

    //setteur et getteur de prenoms
    public void set_prenoms(String prenoms) {
        this.prenoms = prenoms;

    }

    public String get_prenoms() {
        return prenoms;
    }

    //setteur et getteur de sexe
    public void set_sexe(char sexe) {
        this.sexe = sexe;
    }

    public char get_sexe() {
        return sexe;
    }

    //setteur et getteur de dataNaissance
    public void set_dataNaissance(String dataNaissance) {
        this.dateNaissance = dataNaissance;
    }

    public String get_dataNaissance() {
        return dateNaissance;
    }
    //setteur et getteur de parent

    public void set_parent(Personne parent) {
        this.parent = parent;
    }

    public Personne get_parent() {
        return parent;
    }

    //setteur et getteur de enfants
    public void set_enfants(ArrayList<Personne> enfants) {
        this.enfants = enfants;
    }

    public ArrayList<Personne> get_enfants() {
        return enfants;
    }

    //constructeur
    Personne() {
        globalID = 0;
     enfants = new ArrayList<>();
    }

    //fonction de creation d'une personne
    public void creation() {
        id = "0" + (++globalID);
        Scanner sc = new Scanner(System.in);
        System.out.print("\t\t|Veuillez saisir le nom de l'ancetre :");
        nom = sc.nextLine();
        System.out.print("\t\t|Veuillez saisir le prenoms de l'ancetre :");
        prenoms = sc.nextLine();
        sexe = genre();
        dateNaissance = dateLogique();
    }

    // fonction servant à creer une personne enfant
    private void creation(Personne p) {
        this.parent = p;
        nom = p.nom;
        Scanner sc = new Scanner(System.in);
        System.out.print("\t\t|Veuillez saisir le prenoms de l'enfant:");
        prenoms = sc.nextLine();
        sexe = genre();
        dateNaissance = dateLogique();
    }

    // fonction affiche pour afficher toutes les informations d'une personne
    public void affiche() {
        System.out.println("->"+ id + " " + nom + " " + prenoms + ", " + sexe + ", " + dateNaissance);
    }

    public void affiche2() {
        System.out.println("\t\t->"+ id + " " + nom + " " + prenoms + ", " + sexe + ", " + dateNaissance);
    }

    // fonction affiche utiliser pour afficher les ascendants d'une personne
    public void affichePourAscendant() {
        System.out.println("\t\t|-->" + id + " " + nom + " " + prenoms + ", " + sexe + ", " + dateNaissance);
    }

    //fonction de demande et controle de genre
    static  public char genre() {
        Scanner sc = new Scanner(System.in);
        String g = "";
        while (!g.equalsIgnoreCase("1") && !g.equalsIgnoreCase("2")) {
            System.out.println("\t\t|--------Genre---------");
            System.out.println("\t\t|1) -  Masculin :");
            System.out.println("\t\t|2) -  Feminin :");
            System.out.print("\t\t| taper 1 ou 2 : ");
            g = sc.nextLine();
        }
        if (g.equalsIgnoreCase("1"))
            return 'M';
        else
            return 'F';

    }

    //fonction de demande et controle le format de la date de naissance
    public String demandeDate() {
        Scanner sc = new Scanner(System.in);
        String d = "";
        while (dateValide(d) == false) {
            System.out.print("\t\t| Saisir une bonne date de naissance au format(jj/MM/AAAA) : ");
            d = sc.nextLine();
        }
        return d;
    }
    //fonction qui verifie si la date de naissance saisie par l'utilsateur ne donne pas un age superieur à celui du pere
    private  String dateLogique(){
        String date2naissance = demandeDate();
        if (this.parent!=null){
            while (calculAge(date2naissance) >= calculAge(this.parent.dateNaissance)){
                System.out.println("\t\t| un enfant ne peut avoir un age superieur ou egale à son pere/ou infereur à 0!!!! veillez ");
                date2naissance = demandeDate();
                if( calculAge(date2naissance)<0)
                    date2naissance = this.parent.dateNaissance;
            }
        }else {
            while (calculAge(date2naissance) < 0) {
                System.out.println("\t\t| une date de naissance peut pas etre superieur à la date actuelle !!!! veillez ");
                date2naissance = demandeDate();
            }
        }
        return date2naissance;
    }

    // fonction qui verifie si une date de naissance est valide
    private boolean dateValide(String d) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date dtest = dateFormat.parse(d);
            Integer jour = Integer.parseInt(d.substring(0, 2));
            Integer mois = Integer.parseInt(d.substring(3, 5));
            Integer annee = Integer.parseInt(d.substring(6, 10));
            if(jour<1 || jour>31 || mois>12 || mois<1 || annee<1){
                System.out.println("\t\t|  erreur dans la date saisie .");
                return false;
            }
        } catch (ParseException ex) {
            return false;
        }catch (Exception e){
            return false;
        }
        return true;
    }

    // fonction qui permet de creer les enfants d'une personne
    public void demandeEnfant(Arbre arbre) {
        Scanner sc = new Scanner(System.in);
        String reponse1 = "";
        while (!reponse1.equalsIgnoreCase("O") && !reponse1.equalsIgnoreCase("N")) {
            System.out.print("\t\t| voulez-vous enregistrer un enfant ? : O/N : ");
            reponse1 = sc.nextLine();
        }
        if (reponse1.equalsIgnoreCase("O")) {
            String reponse2 = "O";
            while (reponse2.equalsIgnoreCase("O")) {
                Personne p = new Personne();
                p.creation(this);
                enfants.add(p);
                System.out.print("\t\t| voulez vous enregistrer un autre enfant ? : O/N : ");
                reponse2 = sc.nextLine();
            }
            enfants = ordonnerEnfants(enfants);
            int i=0;
            for (Personne p : enfants){
                p.set_idEnfant(get_id()+(++i));
                arbre.ajouterPersonne(p);
            }
        }
    }

    // fonction qui affiche les enfants d'une personne
    public void afficheEnfants() {
        if(!enfants.isEmpty()){
            for (Personne p : enfants)
                p.affiche2();
        }else{
            System.out.println("\t\t|Cette personne n'a aucun enfant...");
        }

    }

    // fonction qui renvoie le nomnbre d'ascendants d'une personne
    public int nombreAscendants() {
        int nbre = 0;Personne p = parent;
        while (p != null) {nbre++;p = p.get_parent(); }
        return nbre;}

    // fonction pour decrementer le globalID
    private void decrementerGlobaleID(){--globalID;}

    // fonction qui permet d'ordonner la liste des enfants d'une personne en fonction de l'age (de l'ainé juqu'au plus petit)
    private ArrayList<Personne> ordonnerEnfants(ArrayList<Personne> p){
        ArrayList<Personne> perso = new ArrayList<>();
        if(!p.isEmpty()){
            int index=0,age=0;
            while (!p.isEmpty()){
                for (Personne p1 : p){
                    if (p1.calculAge(p1.dateNaissance)>age){
                        age = p1.calculAge(p1.dateNaissance);
                        index = p.indexOf(p1);
                    }
                }age = 0;
                perso.add(p.get(index));
                p.remove(index);
            }
        }
        return perso;
    }

    // fonction qui permet de calculer l'age
    public int calculAge(String s){
        int annees = 0;
        try {
             Date naissance = new SimpleDateFormat("dd/MM/yyyy").parse(s);
            // Calendrier pour la naissance.
            Calendar calendrierNaissance = Calendar.getInstance();
            calendrierNaissance.setTimeInMillis(naissance.getTime());
            // Calendrier pour le jour courant.
            Date maintenant = new Date();
            Calendar calendrierMaintenant = Calendar.getInstance();
            calendrierMaintenant.setTimeInMillis(maintenant.getTime());
            // Calcul du nombre d’années.
             annees = calendrierMaintenant.get(Calendar.YEAR) - calendrierNaissance.get(Calendar.YEAR);
        }catch (Exception e){
            System.out.print("\t\t| probleme avec l'age : ");
            return annees;
        }
        return annees;
    }

    // fonction qui renvoie le nomnbre d'ascendants d'une personne
    public Personne renvoiAncetre() {
        Personne p = this.parent;
        Personne p1 = null;
        if(p!=null){
            while (p != null) {
                p1 = p;
                p = p.get_parent(); }
            return p1;
        }else return this;

    }

    // fonction qui reaffecte les id des descendants d'une personne
    public void reaffecteID(){
         int i=0;
        for (Personne p : this.get_enfants()){
            p.set_idEnfant(get_id()+(++i));
            p.reaffecteID();
        }
    }

    //fonction qui verifie si une personne existe dans une liste de personnes
    static public boolean ElementExisteDansListePersonnes(ArrayList<Personne> l, Personne p){
        for (Personne p1 : l){
            if(p1==p)
                return true;
        }
        return false;
    }

    // fonction qui verifie les liens entre deux personnes
    public void lien(Personne p){
        // verifie s'ils sont frere ou soeurs
        if (p.get_parent()!=null && parent!=null){

            if(p.get_parent()==this.get_parent()){
                System.out.println("\t\t|"+get_nom()+" "+get_prenoms()+" et "+p.get_nom()+" "+p.get_prenoms()+" sont des freres(soeurs)...");
                // on verifie si une personne est parent de l'autre
            }else if(Personne.ElementExisteDansListePersonnes(p.get_enfants(),this)==true){
                System.out.println("\t\t|"+p.get_nom()+" "+p.get_prenoms()+", "+p.get_dataNaissance()+" est le parent de "+get_nom()+" "+get_prenoms()+", "+get_dataNaissance());
            }else if(Personne.ElementExisteDansListePersonnes(get_enfants(),p)==true){
                System.out.println("\t\t|"+get_nom()+" "+get_prenoms()+", "+get_dataNaissance()+" est le parent de "+p.get_nom()+" "+p.get_prenoms()+", "+p.get_dataNaissance());
            }
        }
    }
}

