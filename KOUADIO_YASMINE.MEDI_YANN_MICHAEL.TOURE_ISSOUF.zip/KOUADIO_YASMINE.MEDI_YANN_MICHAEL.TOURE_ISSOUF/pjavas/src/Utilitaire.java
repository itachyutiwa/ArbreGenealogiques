import java.io.*;
import java.util.*;

public class Utilitaire {

    Utilitaire(){};
    
    public boolean isLong(String nombre){
        try {
            Long.parseLong(nombre);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public boolean isInt(String nombre){
        try {
            Integer.parseInt(nombre);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public int min(Long[] integers){
        int minVal = Integer.MIN_VALUE;
        for (Long valeur : integers) {
            if(valeur > minVal)
                minVal = Math.toIntExact((Long) valeur);
        }
        return minVal;
    }

    public String searchPersonneByAnnee(Personne [] personnes , int annee){
        String idPers = "";
        for (Personne p : personnes) {
            if (p.dateNaissance == annee) {
                idPers = p.id;
            }
        }
        return idPers;
    }

    public String controle_np(String phrase){
        Scanner sc = new Scanner(System.in);
        this.print(phrase);
        String valeur = sc.nextLine();
        while (valeur.equals("")) {
            this.print(phrase);
            valeur = sc.nextLine();
        }
        return valeur;
    }

    public String controle_sexe(String phrase){
        Scanner sc = new Scanner(System.in);
        this.print("Sexe: (F/f) ou (M:m) ");
        String  sexe = sc.nextLine();
        Boolean asser = sexe.toLowerCase().equals("f") || sexe.toLowerCase().equals("m");
        while (!asser) {
            this.print("Sexe: (F/f) ou (M:m) ");
            sexe = sc.nextLine();
            asser = sexe.toLowerCase().equals("f") || sexe.toLowerCase().equals("m");
        }
        return sexe.toUpperCase();
    }

    public Long controle_naissance(String phrase){
        Scanner sc = new Scanner(System.in);
        System.out.println("Année de naissance: ");
        String  dnaiss = sc.nextLine();
        Boolean asserd = this.isLong(dnaiss);
        while (!asserd) {
            System.out.println("Année de naissance: ");
            dnaiss = sc.nextLine();
            asserd = this.isLong(dnaiss);
        }
        return Long.parseLong(dnaiss);
    }



    public void print(String phrase){
        System.out.println(phrase);
    }

}
