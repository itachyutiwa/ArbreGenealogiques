import java.io.Console;
import java.net.InetAddress;
import java.util.Scanner;
import java.lang.String;

public class creation {

    public static void creation_arbre() {
        Scanner sc = new Scanner(System.in);
        Utilitaire utaire = new Utilitaire();

        System.out.println("\t\t\t\t\t\t CREATION D'UN ARBRE GENEALOGIQUE");
        System.out.print("Famille: ");
        String label = sc.nextLine();

        arbre a = new arbre(label);

        System.out.println();
        System.out.println("\n");
        System.out.println("\t\t\t\t\t\t CREATION DE LA PERSONNE RACINE");

        String nom = utaire.controle_np("Nom : ");
        String prenom = utaire.controle_np("Prenom : ");
        String sexe = utaire.controle_sexe("Sexe (F/f) ou (M:m) :  ");
        Long naissance = utaire.controle_naissance("Année de naissance: ");

        Personne p = new Personne(nom, prenom, a.id, sexe, naissance);
        System.out.println(p.nom + " " + p.prenom);

        a.racine = p.id;
        // System.out.println(a.id);
        // System.out.println(a.racine);
        // System.out.println(p.id);
        stockage.stockerArbre(a);
        stockage.stockerPersonne(p);
        // return a.id;
    }

    public static void creation_personne(String id) {
        arbre a = stockage.recupererArbre(id);
        Personne p = stockage.recupererPersonne(a.racine);
        Scanner sc = new Scanner(System.in);
        Utilitaire utaire = new Utilitaire();
        System.out.println("\t\t\t\t\t\tCREATION D'UNE PERSONNE");

        System.out.println();
        System.out.println("Choix du parent ");

        listing.liste_personne(id);

        String id_p = utaire.controle_np("Entrer l'ID du parent : ");

        String nom = utaire.controle_np("Nom : ");
        String prenom = utaire.controle_np("Prenom : ");
        String sexe = utaire.controle_sexe("Sexe (F/f) ou (M:m) :  ");
        Long naissance = utaire.controle_naissance("Année de naissance: ");

        while (naissance <= p.dateNaissance) {
            System.out.println("Erreur! Cette personne est plus agée que son ancêtre");
            naissance = utaire.controle_naissance("Entrez une année supérieure à " + p.dateNaissance);
        }

        Personne pers = new Personne(nom, prenom, id, sexe, naissance);
        stockage.stockerPersonne(pers);
        lien.pere_fils(pers, id_p);
        // System.out.println("ok");
        stockage.stockerPersonne(pers);
        // return p.id;

    }

}