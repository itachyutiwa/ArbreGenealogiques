/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_ag;
import java.io.Serializable;
import java.util.LinkedList;

/**
 *
 * @author original
 */
public class Personne implements Serializable{
    String id;
    String nom;
    String prenom;
    char sexe;
    String date_de_naissance;
    Personne parent;
    LinkedList<Personne> enfants;
    LinkedList<Personne> freres;
    static int nombreInvdivu = 0;
    
    Personne(String id, String nom, String prenom, char sexe, String date_de_naissance){
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.sexe = sexe;
        this.date_de_naissance = date_de_naissance;
        this.parent = null;
        this.enfants = new LinkedList<>();
        this.freres = new LinkedList<>();
        nombreInvdivu++;
    }

    /**
     *
     * @return String
     */
    @Override
    public String toString(){
        return this.id +" "+ this.nom +" "+ this.prenom +" "+this.sexe+" "+this.date_de_naissance;
    }
    
    public void update(String id,String nom,String prenom,char sexe,String date){
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.sexe = sexe;
        this.date_de_naissance = date;
    }
}
