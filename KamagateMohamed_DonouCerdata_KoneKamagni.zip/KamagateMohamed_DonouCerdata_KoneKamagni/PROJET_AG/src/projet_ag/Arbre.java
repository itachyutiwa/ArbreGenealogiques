/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package projet_ag;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


/**
 *
 * @author original
 */
public class Arbre {
    Personne racine;
    
    Arbre(Personne racine){
        this.racine = racine;
    }
    Arbre(){
        this.racine = null;
    }
    
    public void ajouterEnfant(Personne enfant,String id_parent){
        if(Rechercher(enfant.id) != null)
            System.out.println(" Oups desolez une autre personne de l'arbre utilise deja le même code "+enfant.id);
        else
            if(this.racine == null)
                System.out.println(" Oups l'arbre est vide ");
            else{
                Personne parent = Rechercher(id_parent);
                if(parent != null){
                    if(Integer.parseInt(enfant.date_de_naissance) > Integer.parseInt(parent.date_de_naissance)){
                        //ajouter le pere à l'enfant
                        enfant.parent = parent;
                        //on ajoute tous les autres enfants à la liste des freres de l'enfant à ajouter inversement
                        parent.enfants.forEach((el)->{el.freres.add(enfant);enfant.freres.add(el);});
                        
                        //ajouter l'enfant à la liste des enfants
                        parent.enfants.add(enfant);
                        //parent.enfants.sort();
                        System.out.println(" Enfant ajouté avec succès ");
                    }else
                        System.out.println(" Oups! echec d'ajout car l'age de l'enfant est superieur à celui du  père ");
                        
                }else
                   System.out.println(" Oups erreur d'ajout il n'y a pas de personne avec le code " +id_parent); 
            } 
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeEnfant(String id_parent){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne parent = Rechercher(id_parent);
            if(parent != null)
                if(parent.enfants.isEmpty())
                    System.out.println(" Oups la personne " +parent.toString()+" n'a pas d'enfant");
                else{
                    System.out.println("=========== les enfants de " +parent.toString()+ " ===========");
                    for(Personne el: parent.enfants)
                        System.out.println("\t"+el.toString());
                }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_parent);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeEnfantFils(String id_parent){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne parent = Rechercher(id_parent);
            if(parent != null)
                if(parent.enfants.isEmpty())
                    System.out.println(" Oups la personne " +parent.toString()+" n'a pas de fils");
                else{
                    System.out.println("=========== les Fils de " +parent.toString()+ " ===========");
                    for(Personne el: parent.enfants)
                        if(el.sexe == 'M')
                            System.out.println("\t"+el.toString());
                }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_parent);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeEnfantFille(String id_parent){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne parent = Rechercher(id_parent);
            if(parent != null)
                if(parent.enfants.isEmpty())
                    System.out.println(" Oups la personne " +parent.toString()+" n'a pas de fille");
                else{
                    System.out.println("=========== les Filles de " +parent.toString()+ " ===========");
                    for(Personne el: parent.enfants)
                        if(el.sexe == 'F')
                            System.out.println("\t"+el.toString());
                }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_parent);
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeFrereEtSoeur(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.freres.isEmpty())
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de frères ni de soeurs");
                else{
                    System.out.println("=========== les frères & soeurs de " +personne.toString()+ " ===========");
                    for(Personne el: personne.freres)
                        System.out.println("\t"+el.toString());
                             
                }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeFrere(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.freres.isEmpty())
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de frères");
                else{
                    System.out.println("=========== les frères de " +personne.toString()+ " ===========");
                    for(Personne el: personne.freres)
                        if(el.sexe == 'M')
                            System.out.println("\t"+el.toString()); 
                }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeSoeur(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.freres.isEmpty())
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de soeurs");
                else{
                    System.out.println("=========== les soeurs de " +personne.toString()+ " ===========");
                    for(Personne el: personne.freres)
                        if(el.sexe == 'F')
                            System.out.println("\t"+el.toString()); 
                }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeCousinEtCousine(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.parent == null)
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de cousin, ni cousine car elle est l'ancêtre");
                else{
                    if(personne.parent.freres.isEmpty())
                       System.out.println(" Oups la personne " +personne.toString()+" n'a pas de cousins ni de cousines"); 
                    else{
                        System.out.println("=========== les cousins & cousines de " +personne.toString()+ " ===========");
                        for(Personne el: personne.parent.freres)
                            if(!el.enfants.isEmpty())
                                for(Personne el2: el.enfants)
                                    System.out.println("\t"+el2.toString()); 
                    }   
                }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeCousin(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.parent == null)
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de cousin car elle est l'ancêtre");
                else{
                    if(personne.parent.freres.isEmpty())
                       System.out.println(" Oups la personne " +personne.toString()+" n'a pas de cousins"); 
                    else{
                        System.out.println("=========== les cousins de " +personne.toString()+ " ===========");
                        for(Personne el: personne.parent.freres)
                            if(!el.enfants.isEmpty())
                                for(Personne el2: el.enfants)
                                    if(el2.sexe == 'M')
                                        System.out.println("\t"+el2.toString()); 
                    }   
                }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeCousine(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.parent == null)
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de cousine car elle est l'ancêtre");
                else{
                    if(personne.parent.freres.isEmpty())
                       System.out.println(" Oups la personne " +personne.toString()+" n'a pas de cousine"); 
                    else{
                        System.out.println("=========== les cousins de " +personne.toString()+ " ===========");
                        for(Personne el: personne.parent.freres)
                            if(!el.enfants.isEmpty())
                                for(Personne el2: el.enfants)
                                    if(el2.sexe == 'F')
                                        System.out.println("\t"+el2.toString()); 
                    }   
                }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
   
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeOncleEtTante(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.parent == null)
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas d'oncle, ni de tantes car elle est l'ancêtre");
                else
                    if(personne.parent.freres.isEmpty())
                        System.out.println(" Oups la personne " +personne.toString()+" n'a pas d'oncles ni de tantes");
                    else{
                        System.out.println("=========== les oncles & tantes de " +personne.toString()+ " ===========");
                        personne.parent.freres.forEach((el)->{
                            System.out.println("\t"+el.toString());
                        });  
                    }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeOncle(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.parent == null)
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas d'oncle car elle est l'ancêtre");
                else
                    if(personne.parent.freres.isEmpty())
                        System.out.println(" Oups la personne " +personne.toString()+" n'a pas d'oncle");
                    else{
                        System.out.println("=========== les oncles de " +personne.toString()+ " ===========");
                        personne.parent.freres.forEach((el)->{
                            if(el.sexe == 'M')
                            System.out.println("\t"+el.toString());
                        });  
                    }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeTante(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.parent == null)
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de tante car elle est l'ancêtre");
                else
                    if(personne.parent.freres.isEmpty())
                        System.out.println(" Oups la personne " +personne.toString()+" n'a pas de tante");
                    else{
                        System.out.println("=========== les tantes de " +personne.toString()+ " ===========");
                        personne.parent.freres.forEach((el)->{
                            if(el.sexe == 'F')
                                System.out.println("\t"+el.toString());
                        });   
                    }    
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeNeveuEtNiece(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.freres.isEmpty())
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de neveu ni de niece");
                else{
                    System.out.println("=========== les neveux & nieces de " +personne.toString()+ " ===========");
                    for(Personne el:personne.freres)
                        if(!el.enfants.isEmpty())
                            el.enfants.forEach((el_2)->{
                                System.out.println("\t"+el_2.toString());
                            });   
                }          
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeNeveu(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.freres.isEmpty())
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de neveu");
                else{
                    System.out.println("=========== les neveux de " +personne.toString()+ " ===========");
                    for(Personne el:personne.freres)
                        if(!el.enfants.isEmpty())
                            el.enfants.forEach((el_2)->{
                                if(el_2.sexe == 'M')
                                    System.out.println("\t"+el_2.toString());
                            });   
                }          
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeNiece(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.freres.isEmpty())
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de niece");
                else{
                    System.out.println("=========== les nieces de " +personne.toString()+ " ===========");
                    for(Personne el:personne.freres)
                        if(!el.enfants.isEmpty())
                            el.enfants.forEach((el_2)->{
                                if(el_2.sexe == 'F')
                                    System.out.println("\t"+el_2.toString());
                            });   
                }          
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void modifierPersonne(String id,String nom,String prenom, String sexe, String date, String ancien_id){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne p = Rechercher(ancien_id);
            if(p == null)
               System.out.println(" Oups il n'y a pas de personne avec le code " +ancien_id);
            else{
                String p_id = id == null? p.id:id;
                String p_nom = nom == null?p.nom:nom;
                String p_prenom = prenom == null?p.prenom:prenom;
                String p_sexe = sexe == null?Character.toString(p.sexe):sexe;
                String p_date = date == null?p.date_de_naissance:date;
                System.out.println(p_id);
                if(!p_id.equals(p.id))
                    if(Rechercher(p_id) != null)
                        System.out.println(" Oups il existe deja une autre personne avec le code le code nouveau code( "+p_id+" ) que vous tentez d'ajouter");
                    else{
                        p.update(p_id,p_nom,p_prenom,p_sexe.charAt(0),p_date);
                        System.out.println(" Modification effectuée avec succès ");
                    }       
                else{
                    p.update(p_id,p_nom,p_prenom,p_sexe.charAt(0),p_date);
                    System.out.println(" Modification effectuée avec succès ");
                }
            }
        } 
    }
    
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void listeAscendant(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            ArrayList<Personne> liste = new ArrayList<>();
            ArrayList<Personne> liste_2 = new ArrayList<>();
            liste.add(racine);
            if(personne != null){
                if(personne.parent == null)
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas d'ascendant car elle est l'ancêtre");
                else{
                    Personne p = personne.parent;
                    System.out.println("=========== les ascendants de " +personne.toString()+ " ===========");
                    while(!liste.isEmpty()){
                        for(Personne el: liste){
                            System.out.println(getTab(getNiveau(el))+""+el.toString());
                            el.enfants.forEach((el_2)->{
                                liste_2.add(el_2);
                            });              
                        }
                        if(liste.contains(p))
                            break;
                        liste.clear();
                        liste_2.forEach((el)->{liste.add(el);});
                        liste_2.clear();
                    }
                }
            }else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void listeDescendant(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            ArrayList<Personne> liste = new ArrayList<>();
            ArrayList<Personne> liste_2 = new ArrayList<>();

            if(personne != null){
                if(personne.enfants.isEmpty())
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de descendant ");
                else{               
                    personne.enfants.forEach((el)->{liste.add(el);});              
                    System.out.println("=========== les descendants de " +personne.toString()+ " ===========");
                    while(!liste.isEmpty()){
                        for(Personne el: liste){
                            System.out.println(getTab(getNiveau(el))+""+el.toString());
                            el.enfants.forEach((el_2)->{
                                liste_2.add(el_2);
                            });              
                        }
                        liste.clear();
                        liste_2.forEach((el)->{liste.add(el);});
                        liste_2.clear();
                    }
                }
            }else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public void parent(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.parent == null)
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de parent car il est l'ancêtre");
                else{
                    System.out.println("=========== le parent de " +personne.toString()+ " ===========");
                    System.out.println("\t"+personne.parent.toString());   
                }          
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    /**
     *
     * @param id_personne
     */
    public void frereAine(String id_personne){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            Personne personne = Rechercher(id_personne);
            if(personne != null)
                if(personne.parent == null)
                    System.out.println(" Oups la personne " +personne.toString()+" n'a pas de frère ainé car il est l'ancêtre");
                else{
                    Personne aine = personne.parent.enfants.getFirst();
                    for(Personne el:personne.parent.enfants)
                        if(Integer.parseInt(el.date_de_naissance)<Integer.parseInt(aine.date_de_naissance))
                            aine = el;
                    if(aine.equals(personne))
                        System.out.println(" Oups la personne " +personne.toString()+" est elle même l'ainé de ses freres");
                    else{
                        System.out.println("=========== le frère ainé de " +personne.toString()+ " ===========");
                        System.out.println("\t"+aine.toString());
                    }   
                }          
            else
                System.out.println(" Oups il n'y a pas de personne avec le code " +id_personne);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //Algorithme de parcours en largeur
    public Personne Rechercher(String id){
        //Liste des elements à tester
        ArrayList<Personne> liste = new ArrayList<>();
        //litse des enfants de chaque elements qu'on aura tester
        ArrayList<Personne> liste_2 = new ArrayList<>();
        liste.add(racine);
        while(!liste.isEmpty()){
            //pour chaque noeud de liste
            for(Personne el: liste)
                //si un noeud est notre element on le retourne
                if(el.id.equals(id))
                    return el;
                else
                    //sinon on ajoute ses enfants a la liste des enfants
                    el.enfants.forEach((el_2)->{liste_2.add(el_2);});
            //on supprime les elements deja tester
            liste.clear();
            //on ajouter les nouveaux elements à tester
            liste_2.forEach((el)->{liste.add(el);});
            //on vide liste_2
            liste_2.clear();
        }
        return null;
    }
    
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void enregistrerDansFichier(){
        if(this.racine == null)
            System.out.println(" Oups l'arbre est vide ");
        else{
            ObjectOutputStream saveArbre;
            try{
                saveArbre = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File("arbre.txt"))));
                saveArbre.writeObject(this.racine);
                saveArbre.close();
                System.out.println("Sauvegarde effecutée avec succès.");
            }catch(FileNotFoundException e){
                System.out.println("fichier arbre.txt n'existe pas");
            }catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void chargerArbreDepuisFichier(){
        ObjectInputStream getArbre;
        try{
            getArbre = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("arbre.txt"))));
            try {
                this.racine = (Personne)getArbre.readObject();
                getArbre.close();
                System.out.println("Arbre chargé avec succès.");
            } catch (ClassNotFoundException ex) {
                System.out.println("oups erreur il n'y à pas de classe paersonne");
            }
        }catch(FileNotFoundException e){
            System.out.println("fichier arbre.txt n'existe pas");
        }catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    void parcours(Personne courant){
        System.out.println(getTab(getNiveau(courant))+""+courant.toString());
        for(Personne el:courant.enfants){
            parcours(el);
        }
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private String getTab(int niveau){
        String tab = "";
        for(int i=1; i<=niveau;i++)
            tab += "\t";
        return tab;
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    private int getNiveau(Personne personne){
        ArrayList<Personne> liste = new ArrayList<>();
        ArrayList<Personne> liste_2 = new ArrayList<>();
        liste.add(racine);
        int niveau = 0;
        while(!liste.isEmpty()){
            niveau++;
            if(liste.contains(personne))
                break;
            else{
                for(Personne el: liste)
                    el.enfants.forEach((el_2)->{liste_2.add(el_2);});
                liste.clear();
                liste_2.forEach((el)->{liste.add(el);});
                liste_2.clear(); 
            }    
        }
        return niveau;
    }
}
