/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projet_ag;


import java.util.Scanner;

/**
 *
 * @author original
 */
public class App {
    static Arbre arbre = null;
    static Scanner _sc = new Scanner(System.in);
    
    static void start(){
        boolean continuer = true;
      
        nomEtudiant();
        System.out.println("\t\t++++++    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    ++++++");
        System.out.println("\t\t++++++                                        MENU APPLICATION                                                   ++++++");
        System.out.println("\t\t++++++   AVANT TOUTES OPERATIONS VEUILLEZ CHARGER L ARBRE DEPUIS LE FICHIER OPTION: '1' CAR INITIALEMENT VIDE    ++++++");
        while(continuer){
            menu();
            System.out.print("\n\n Entrer O|o|Y|y pour continuer ou entrer pour quitter :");
            String etat = _sc.nextLine();
            
            if(!etat.equals("O") && !etat.equals("o") && !etat.equals("Y") && !etat.equals("y"))
                continuer =false;
        }
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    static void nomEtudiant(){
    
    try {
        System.out.print("\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t     ____________________________________________________\n"); Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t            /                                                     \\ \n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |    _____________________________________________     |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |                                             |    |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |                                             |    |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |                                             |    |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |                                             |    |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |    PROF: Pr. GOORE BI TRA                   |    |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |                                             |    |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |    ETUDIANTS:  _KAMAGATE BADIHOUI           |    |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |                _DONOU CERDATA               |    |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |                _KONE KAMAGNI CHARLES             |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |   |_____________________________________________|    |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           |                                                      |\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t           \\_____________________________________________________/\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t                   \\_______________________________________/\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t                ____________(___________________)______________\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t             _-'    .-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.  --- `-_\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t          _-'.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.--.  .-.-.`-_\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t       _-'.-.-.-. .---.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-`__`. .-.-.-.`-_\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t    _-'.-.-.-.-. .-----.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-----. .-.-.-.-.`-_\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t _-'.-.-.-.-.-. .---.-. .-----------------------------. .-.---. .---.-.-.-.`-_\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t:-----------------------------------------------------------------------------:\n");Thread.sleep(350);
        System.out.print("\t\t\t\t\t\t`---._.-----------------------------------------------------------------._.---'\n");Thread.sleep(350);
        Thread.sleep(1000);
    } catch (InterruptedException e) {
        e.printStackTrace();
    }

       
} 







    
    static void menu(){
 
        System.out.println("\t\t++++++    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    ++++++");
        System.out.println("\t\t++++++    +++++     1-Pour charger l'arbre      2-Pour enregistrer l'arbre     3-Pour créer un arbre    +++++    ++++++");
        System.out.println("\t\t++++++    +++++    4-Pour ajouter un enfant    5-Pour afficher les freres   6-Pour afficher les cousins +++++    ++++++");
        System.out.println("\t\t++++++    +++++  7-Pour afficher les oncles   8-Pour afficher les neveux   9-Pour afficher les enfants  +++++    ++++++");
        System.out.println("\t\t++++++    +++ 10-Pour afficher les ascendants 11-Pour afficher les descendants 12-Pour afficher le parent +++    ++++++");
        System.out.println("\t\t++++++    +++ 13-Pour afficher le frère ainé 14-Pour parcourir l' arbre 15-Pour Modifier  une personne    +++    ++++++");
        System.out.println("\t\t++++++    +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    ++++++");
        System.out.print( "\n\t\t\tVeuillez entrer votre le numéro de votre oppération : " );
        String choix = _sc.nextLine();
        opperation(choix);
    }
    
    static String verificationEntier(String chaine){
        
        while( !chaine.matches("^?\\d+$")){
            System.out.println(" Oups Mauvaise entrée! entier svp");
            chaine = _sc.nextLine();
        }
        return chaine;
    }
    
    static void opperation(String choix){
        switch(choix){
            case "1":
                System.out.println("\n");
                arbre = new Arbre();
                arbre.chargerArbreDepuisFichier();
                break;
            case "2":
                System.out.println("\n");
                if(arbre != null)
                    arbre.enregistrerDansFichier();
                else
                    System.out.println( " Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "3":
                arbre = new Arbre(creerPersonne("ancetre"));
                System.out.println( "\t\t\t Ancêtre crée avec succès " );
                break;
            case "4":
                System.out.println("\n");
                if(arbre != null){
                    Personne p = creerPersonne("autre");
                    System.out.print( "\t\t\t Veuillez entrer l' identifiant du parent(entier svp) : " );
                    String   id = _sc.nextLine();
                    arbre.ajouterEnfant(p, id);
                    
                }
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "5":
                System.out.println("\n");
                if(arbre != null)
                    afficherFrere();
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "6":
                System.out.println("\n");
                if(arbre != null)
                    afficherCousin();
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "7":
                System.out.println("\n");
                if(arbre != null)
                    afficherOncle();
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "8":
                System.out.println("\n");
                if(arbre != null)
                    afficherNeveu();
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "9":
                System.out.println("\n");
                if(arbre != null)
                    afficherEnfant();
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "10":
                System.out.println("\n");
                if(arbre != null){
                    System.out.print( "\t\t\t Veuillez entrer l' identifiant d'une personne : " );
                    String id = _sc.nextLine();
                    arbre.listeAscendant(id);
                }   
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "11":
                System.out.println("\n");
                if(arbre != null){
                    System.out.print( "\t\t\t Veuillez entrer l' identifiant d'une personne : " );
                    String id = _sc.nextLine();
                    arbre.listeDescendant(id);
                }   
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "12":
                System.out.println("\n");
                if(arbre != null){
                    System.out.print( "\t\t\t Veuillez entrer l' identifiant d'une personne : " );
                    String id = _sc.nextLine();
                    arbre.parent(id);
                }   
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "13":
                System.out.println("\n");
                if(arbre != null){
                    System.out.print( "\t\t\t Veuillez entrer l' identifiant d'une personne : " );
                    String id = _sc.nextLine();
                    arbre.frereAine(id);
                }   
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "14":
                System.out.println("\n");
                System.out.println("\t\t++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                System.out.println("\t\t+++++++++++ Affichage complet de l'arbre +++++++++++++");
                System.out.println("\t\t++++++++++++++++++++++++++++++++++++++++++++++++++++++");
                if(arbre != null)
                    arbre.parcours(arbre.racine);
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            case "15":
                System.out.println("\n");
                if(arbre != null)
                    modiffierPersonne();
                else
                    System.out.println( "Oups créer d'abord un arbre ou charger l' arbre existant" );
                break;
            default:
                System.out.println( "\t\t\t Oups Choix invalide " );
        }
    }
 
    static Personne creerPersonne(String type){
        if(type.equals("ancetre")){
            System.out.println("\t\t++++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("\t\t+++++++++++ Création de l' ancêtre +++++++++++++");
            System.out.println("\t\t++++++++++++++++++++++++++++++++++++++++++++++++");
        }else{
            System.out.println("\t\t++++++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("\t\t++++++++++ Création d'une personne +++++++++++++");
            System.out.println("\t\t++++++++++++++++++++++++++++++++++++++++++++++++");
        }
        
        System.out.print( "\t\t\t Veuillez entrer son identifiant : " );
        String id = _sc.nextLine(); 
        String idNew = verificationEntier(id);
        System.out.print( "\t\t\t Veuillez entrer son nom : " );
        String nom = _sc.nextLine();
        System.out.print( "\t\t\t Veuillez entrer son prénom : " );
        String prenom = _sc.nextLine();
        System.out.print( "\t\t\t Veuillez entrer son sexe(M/F) : " );
        String sexe = _sc.nextLine();
        System.out.print( "\t\t\t Veuillez entrer son année de naissance : " );
        String date = _sc.nextLine();
        String dateNew = verificationEntier(date);
        return new Personne(idNew,nom,prenom,sexe.charAt(0),dateNew);      
    }
    static void modiffierPersonne(){
        System.out.print( "\t\t\t Veuillez entrer l'identifiant de la personne à modifier : " );
        String old_id = _sc.nextLine();
        String id = null;
        String nom = null;
        String prenom = null;
        String sexe = null;
        String date = null;
        String scan;
        System.out.print( "\t\t\t Veuillez entrer son nouveau identifiant ou taper entrer pour passer : " );
        scan = _sc.nextLine();
        if(scan != null && !scan.equals(""))
            id = scan;
        System.out.print( "\t\t\t Veuillez entrer son nouveau nom ou taper entrer pour passer : " );
        scan = _sc.nextLine();
        if(scan != null && !scan.equals(""))
            nom = scan;
        System.out.print( "\t\t\t Veuillez entrer son nouveau prenom ou taper entrer pour passer : " );
        scan = _sc.nextLine();
        if(scan != null && !scan.equals(""))
            prenom = scan;
        System.out.print( "\t\t\t Veuillez entrer son nouveau sexe ou taper entrer pour passer : " );
        scan = _sc.nextLine();
        if(scan != null && !scan.equals(""))
            sexe = scan;
        System.out.print( "\t\t\t Veuillez entrer sa nouvelle année de naissance ou taper entrer pour passer : " );
        scan = _sc.nextLine();
        if(scan != null && !scan.equals(""))
            date = scan;
        arbre.modifierPersonne(id, nom, prenom, sexe, date, old_id);
    }
    static void afficherFrere(){
        System.out.print( "\t\t\t Veuillez entrer l' identifiant d'une personne : " );
        String id = _sc.nextLine();
        System.out.println("\t\t 1-Pour afficher ses frères et soeurs");
        System.out.println("\t\t 2-Pour afficher ses frères");
        System.out.println("\t\t 3-Pour afficher ses soeurs");
        System.out.print( "\t\t\t Veuillez entrer votre choix : " );
        String choix = _sc.nextLine();
        switch(choix){
            case "1":
                arbre.listeFrereEtSoeur(id);
                break;
            case "2":
                arbre.listeFrere(id);
                break;
            case "3":
                arbre.listeSoeur(id);
                break;
            default:
                System.out.println( "\t\t\t Oups Choix invalide " );
        }
    }
    static void afficherCousin(){
        System.out.print( "\t\t\t Veuillez entrer l' identifiant d'une personne : " );
        String id = _sc.nextLine();
        System.out.println("\t\t 1-Pour afficher ses cousins et cousines ");
        System.out.println("\t\t 2-Pour afficher ses cousins");
        System.out.println("\t\t 3-Pour afficher ses cousines");
        System.out.print( "\t\t\t Veuillez entrer votre choix : " );
        String choix = _sc.nextLine();
        switch(choix){
            case "1":
                arbre.listeCousinEtCousine(id);
                break;
            case "2":
                arbre.listeCousin(id);
                break;
            case "3":
                arbre.listeCousine(id);
                break;
            default:
                System.out.println( "\t\t\t Oups Choix invalide " );
        }
    }
    static void afficherOncle(){
        System.out.print( "\t\t\t Veuillez entrer l' identifiant d'une personne : " );
        String id = _sc.nextLine();
        System.out.println("\t\t 1-Pour afficher ses oncles et tantes ");
        System.out.println("\t\t 2-Pour afficher ses oncles");
        System.out.println("\t\t 3-Pour afficher ses tantes");
        System.out.print( "\t\t\t Veuillez entrer votre choix : " );
        String choix = _sc.nextLine();
        switch(choix){
            case "1":
                arbre.listeOncleEtTante(id);
                break;
            case "2":
                arbre.listeOncle(id);
                break;
            case "3":
                arbre.listeTante(id);
                break;
            default:
                System.out.println( "\t\t\t Oups Choix invalide " );
        }
    }
    static void afficherNeveu(){
        System.out.print( "\t\t\t Veuillez entrer l' identifiant d'une personne : " );
        String id = _sc.nextLine();
        System.out.println("\t\t 1-Pour afficher ses neveux et nièces ");
        System.out.println("\t\t 2-Pour afficher ses neveux");
        System.out.println("\t\t 3-Pour afficher ses nièces");
        System.out.print( "\t\t\t Veuillez entrer votre choix : " );
        String choix = _sc.nextLine();
        switch(choix){
            case "1":
                arbre.listeNeveuEtNiece(id);
                break;
            case "2":
                arbre.listeNeveu(id);
                break;
            case "3":
                arbre.listeNiece(id);
                break;
            default:
                System.out.println( "\t\t\t Oups Choix invalide " );
        }
        
    }
    static void afficherEnfant(){
        System.out.print( "\t\t\t Veuillez entrer l' identifiant d'une personne : " );
        String id = _sc.nextLine();
        System.out.println("\t\t 1-Pour afficher ses fils et filles ");
        System.out.println("\t\t 2-Pour afficher ses fils");
        System.out.println("\t\t 3-Pour afficher ses filles");
        System.out.print( "\t\t\t Veuillez entrer votre choix : " );
        String choix = _sc.nextLine();
        switch(choix){
            case "1":
                arbre.listeEnfant(id);
                break;
            case "2":
                arbre.listeEnfantFils(id);
                break;
            case "3":
                arbre.listeEnfantFille(id);
                break;
            default:
                System.out.println( "\t\t\t Oups Choix invalide " );
        }
    }
    
}
