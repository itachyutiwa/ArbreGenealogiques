import java.io.*;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.Scanner;

public class Person implements Serializable {
    private static int nbre = 0;
    private String ident;
    private String nom;
    private String prenoms;
    private int annee;
    private String sexe;
    private Person pere;
    private LinkedList<Person> enfant;

    public Person() {
        ident = "0"+ (nbre++);
        enfant = new LinkedList<>();
        pere = null;
    }
    public void setIdEnfant(String id){
        this.ident = id;
    }

    public String getIdent() {
        return ident;
    }

    public void setIdent(String ident) {
        this.ident = ident;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenoms() {
        return prenoms;
    }

    public void setPrenoms(String prenoms) {
        this.prenoms = prenoms;
    }

    public int getAnnee() {
        return annee;
    }

    public void setAnnee(int annee) {
        this.annee = annee;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public LinkedList<Person> getEnfant() {
        return enfant;
    }

    public void setEnfant(LinkedList<Person> enfant) {
        this.enfant = enfant;
    }

    public Person getPere() {
        return pere;
    }

    public void setPere(Person pere) {
        this.pere = pere;
    }

    public static String sexe() {
        Scanner clavier = new Scanner(System.in);
        String choix;
        do {
            System.out.println("Choisissez votre sexe : ");
            System.out.println("f pour féminin");
            System.out.println("m pour Masculin");
            System.out.print("Choix :");
            choix = clavier.nextLine();

        } while (!choix.equalsIgnoreCase("f") && !choix.equalsIgnoreCase("m"));
        return choix;

    }

    public void CreerPersonne() {
        System.out.println("-----------------------------------------------------------------------------");
        System.out.println("                             CREATION D'UNE PERSONNE                         ");
        System.out.println("-----------------------------------------------------------------------------");
        Person p = new Person();
        Scanner clavier = new Scanner(System.in);
        System.out.print("Entrer votre nom : ");
        nom = clavier.nextLine();
        System.out.print("Entrer votre prenoms : ");
        prenoms = clavier.nextLine();
        sexe = Person.sexe();
        System.out.print("Entrer l'année : ");
        annee = clavier.nextInt();

    }


    public void CreEnfant() {
        System.out.println("-------------------------------------------------------------");
        System.out.println("             CREATION DES ENFANTS D'UNE PERSONNE             ");
        System.out.println("-------------------------------------------------------------");
        Scanner clavier1 = new Scanner(System.in);
        boolean ok = false;
        System.out.println("Voulez vous creer des enfants ???");
        System.out.println("1- OUI");
        System.out.println("2- NON");
        String reponse = clavier1.nextLine();
        if (reponse.equalsIgnoreCase("1")) {
            ok = true;
        }else
            Menu.menuArbre();
        while (ok == true) {
            System.out.println("--------------------------------------------");
            Person p = new Person();
            p.setNom(this.getNom());
            p.setPere(this);
            System.out.print("Entrez le prénom de l'enfant : ");
            String pre = clavier1.nextLine();
            p.setPrenoms(pre);
            p.setSexe(Person.sexe());
            System.out.println("--------------------------------------------");
            System.out.print("Entrez l'année de naissance de l'enfant : ");
            int a = clavier1.nextInt();
            p.setAnnee(p.age_correct(a));
            this.enfant.add(p);
            System.out.println("--------------------------------------------");
            System.out.println("Voulez-vous enregistrez un autre enfant ?");
            System.out.println("1- OUI");
            System.out.println("2- NON");
            reponse = clavier1.nextLine();
            reponse = clavier1.nextLine();
            if (reponse.equalsIgnoreCase("1")) {
                ok = true;
            } else {
                ok = false;
            }

        }
        this.Tri_Enfant();
        int a = 1;
        for(Person i :enfant){
            i.setIdEnfant(getIdent()+(++a));
        }
        Menu.menuArbre();
    }

    public void affichePersonne() {
        System.out.println("++ "+getIdent()+ " " +getNom()+ " " +getPrenoms()+ " " +getSexe()+ " " +getAnnee());
    }

    public void afficheEnfant() {
        if (!this.getEnfant().isEmpty()){
            for (Person i : this.getEnfant()) {
                i.affichePersonne();
            }
        }else System.out.print(" cette personne n'a pas d'enfants .");


    }
    public void Pere() {
        Person p = pere;
        p.affichePersonne();

    }

    public void Ascendant() {
        Person p = pere;
        while (p != null) {
            p.affichePersonne();
            p = p.pere;
        }
    }

    public void ListeFrereSoeur() {
        Person p = pere;
        if (p != null) {
            for (Person i : p.enfant) {
                if (i != this) {
                    i.affichePersonne();
                }
            }
        }
    }

    public void Cousin() {
        Person p = getPere().getPere();
        if (p != null) {
            for (Person i : p.getEnfant()) {
                if (i != this.getPere())
                    i.afficheEnfant();
            }
        }
    }

    public int nbre_Ascendant() {
        int cpt = 0;
        Person p = pere;
        while (p != null) {
            cpt++;
            p = p.pere;
        }
        return cpt;
    }


    public void Tri_Enfant() {
        LinkedList<Person> enf_ord = new LinkedList<>();
        int ag = -1;
        int id = 0;
        Person p_recup = null;
        while (!enfant.isEmpty()) {
            for (Person elt : enfant) {
                if (elt.annee > ag) {
                    ag = elt.annee;
                    id = enfant.indexOf(elt);
                    p_recup = elt;
                }
            }
            enf_ord.add(p_recup);
            enfant.remove(id);
            ag = -1;
        }
        Collections.reverse(enf_ord);
        enfant =enf_ord;
    }

    public int age_correct(int age) {
        Scanner cl = new Scanner(System.in);
        while (age <= pere.getAnnee()) {
            System.out.println("l'année de l'enfant ne peut pas être supérieure à celle du père.");
            System.out.print("Entrez la nouvelle date : ");
            age = cl.nextInt();
        }
        return age;
    }

    public void ModifierPersonne(Arbre A1) {
        System.out.print("----------------------------------------------------------");
        System.out.print("                     MODIFICATION                         ");
        System.out.print("----------------------------------------------------------");
        Scanner clavier = new Scanner(System.in);
        System.out.println("Veuiller choisir l'option que vous voulez modifier : ");
        System.out.print("1- Modifier le nom\n");
        System.out.print("2- Modifier le prénom\n");
        System.out.print("3- Modifier le sexe\n");
        System.out.print("4- Modifier la date de naissance\n");
        System.out.print("5- RETOUR\n");
        System.out.print("Choix : ");
        String choix = clavier.nextLine();

        switch (choix) {
            case "1":
                System.out.print("Entrez le nouveau nom : ");
                String nom = clavier.nextLine();
                this.setNom(nom);
                A1.Serialiser();
                System.out.print("Modification effectué avec succès");
                System.out.println("-------------------------------------");
                ModifierPersonne(A1);
                break;
            case "2":
                System.out.print("Entrez le nouveau prenom : ");
                String prenom = clavier.nextLine();
                setPrenoms(prenom);
                A1.Serialiser();
                System.out.print("Modification effectué avec succès");
                System.out.println("-------------------------------------");
                ModifierPersonne(A1);
                break;
            case "3":
                setSexe(Person.sexe());
                A1.Serialiser();
                System.out.println("-------------------------------------");
                System.out.print("Modification effectuer avec succès");
                ModifierPersonne(A1);
                break;
            case "4":
                System.out.print("Entrer la nouvelle date de naissance : ");
                int date = clavier.nextInt();
                setAnnee(date);
                A1.Serialiser();
                System.out.print("Modification effectué avec succès");
                System.out.println("-------------------------------------");
                ModifierPersonne(A1);
                break;
            case "5":

                break;

        }
    }


}