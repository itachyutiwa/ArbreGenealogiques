import java.io.*;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Scanner;

public class Arbre implements Serializable {
    LinkedList<Person> membres = new LinkedList<>();

    public void Serialiser() {
        try {
            FileOutputStream fos = new FileOutputStream("serialiser.txt");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(this);
        } catch (FileNotFoundException e) {
            System.out.println("erreur de sériéalisation");
        } catch (IOException e) {
            System.out.println("erreur de sériéalisation");
        }

    }

    public static Arbre Deserialiser() {
        Arbre A1 =new Arbre();
        try {
            FileInputStream fis = new FileInputStream("serialiser.txt");
            ObjectInputStream ois = new ObjectInputStream(fis);
            A1 = (Arbre) ois.readObject();

        } catch (FileNotFoundException e) {
            System.out.println("fichier introuvable");

            return A1;
        } catch (IOException e) {
            System.out.println("impossible de lire");

            return A1;
        } catch (ClassNotFoundException e) {
            System.out.println("probleme avec la classe");

            return A1;
        }
        return A1;
    }


    public void AfficherArbre(Person p1){
        for(int i = 0 ; i < p1.nbre_Ascendant(); i++){
            System.out.print("\t");
        }
        p1.affichePersonne();
        for (Person j : p1.getEnfant()){
            AfficherArbre(j);
        }
    }
    public void Creer(){
        Person p1 = new Person();
        p1.CreerPersonne();
        this.membres.add(p1);
        //this.Serialiser();
        p1.CreEnfant();
        if(p1.getEnfant()==null)
            System.out.print("Pas d'enfant");
        else
            membres.addAll(p1.getEnfant());

        this.Serialiser();
    }

    public void AfficherMembre(){
        for (Person i :this.membres){
            i.affichePersonne();
        }
    }

    public Person RetrouverPeronneId(){
        Scanner clavier = new Scanner(System.in);
        Person p1 =null;
        System.out.print("Identifiant personne : ");
        String ident= clavier.nextLine();
        for (Person i : membres){
            if (i.getIdent().equalsIgnoreCase(ident)){
                p1 =i;
                break;
            }
        }

      return p1;
    }
public static void Affiche(){
    System.out.println("-------------------------------------------------------------");
    System.out.println("|          OPTION CONCERNANT UN MEMBRE SELECTIONNE          |");
    System.out.println("-------------------------------------------------------------");
    System.out.print("1 - Afficher arbre\n");
    System.out.print("2 - Liste enfant\n");
    System.out.print("3 - frere et soeurs\n");
    System.out.print("4 - Père\n");
    System.out.print("5 - cousins\n");
    System.out.print("6 - ascendants\n");
    System.out.print("7 - frère ainé\n");
    System.out.print("8 - Continuer arbre (Créer enfant d'une personne)\n");
    System.out.print("0 - Menu générale\n");
    System.out.print("Votre choix : ");
}
public static void menuArbre1(Arbre A1){
    System.out.println("Liste des membres de l'arbre");
    A1.AfficherMembre();
    System.out.println("\n----------------------------------------------");
    System.out.println("Entrer l'identifiant d'une personne pour voir les autres options");
    Person p = A1.RetrouverPeronneId();
    if (p==null){
        System.out.println("personne non trouvé");
        A1.RetrouverPeronneId();
        Affiche();
        menuArbre1(A1);
    }

    else{
        Scanner cl = new Scanner(System.in);
        System.out.println("----------------------------------------------");
        Affiche();
        System.out.println("----------------------------------------------");
        String choix = cl.nextLine();
        String reponse;
        switch (choix) {
            case "1":
                System.out.println("--------------------------------------");
                System.out.println("l'arbre de la personne sélectionnée");
                System.out.println("--------------------------------------");
                A1.AfficherArbre(p);
                System.out.println("0 - retour");
                System.out.println("00- Menu generale");
                System.out.println("reponse: 1");
                reponse = cl.nextLine();
                switch (reponse){
                    case "0" :
                        if (reponse.equalsIgnoreCase("0"))
                            menuArbre1(A1);
                        Menu.clearConsole();
                        Affiche();
                        menuArbre1(A1);
                    case "00":
                        Menu.menuArbre();
                }


                break;
            case "2":
                System.out.println("------------------------------------------------------");
                System.out.println("voici la liste des enfants d'une personne sélectionnée");
                System.out.println("------------------------------------------------------");
                p.afficheEnfant();
                System.out.println("--------------------------------------");
                System.out.println("0 - retour");
                System.out.println("00- Menu generale");
                System.out.println("reponse: 1");
                reponse = cl.nextLine();
                switch (reponse){
                    case "0" :
                        if (reponse.equalsIgnoreCase("0"))
                            menuArbre1(A1);
                        Menu.clearConsole();
                        Affiche();
                        menuArbre1(A1);
                    case "00":
                        Menu.menuArbre();
                }
                break;
            case "3":
                System.out.println("-------------------------------------------------------------");
                System.out.println("voici la liste des frère et soeur d'une personne sélectionnée");
                System.out.println("-------------------------------------------------------------");
                if (p.getPere()==null)
                    System.out.println("il est ancêtre");
                else{
                    if (p.getPere().getEnfant().size()==1)
                        System.out.println("il est unique");
                    else
                        p.ListeFrereSoeur();
                }
                System.out.println("--------------------------------------");
                System.out.println("0 - retour");
                System.out.println("00- Menu generale");
                System.out.println("reponse: 1");
                reponse = cl.nextLine();
                switch (reponse){
                    case "0" :
                        if (reponse.equalsIgnoreCase("0"))
                            menuArbre1(A1);
                        Menu.clearConsole();
                        Affiche();
                        menuArbre1(A1);
                    case "00":
                        Menu.menuArbre();
                }
                System.out.println("--------------------------------------");
                break;
            case "4":
                System.out.println("-------------------------------------------------------------");
                System.out.println("Le père d'une personne sélectionnée");
                System.out.println("-------------------------------------------------------------");
                if (p.getPere()==null)
                    System.out.println("il est ancêtre");
                else
                    p.Pere();
                System.out.println("--------------------------------------");
                System.out.println("0 - retour");
                System.out.println("00- Menu generale");
                System.out.println("reponse: 1");
                reponse = cl.nextLine();
                switch (reponse){
                    case "0" :
                        if (reponse.equalsIgnoreCase("0"))
                            menuArbre1(A1);
                        Menu.clearConsole();
                        Affiche();
                        menuArbre1(A1);
                    case "00":
                        Menu.menuArbre();
                }
                System.out.println("--------------------------------------");
                break;
            case "5":
                System.out.println("-------------------------------------------------------------");
                System.out.println("Les cousins d'une personne sélectionnée");
                System.out.println("-------------------------------------------------------------");
                if (p.getPere()==null)
                    System.out.println("il est l'ancêtre");
                else
                    p.Cousin();
                System.out.println("--------------------------------------");
                System.out.println("0 - retour");
                System.out.println("00- Menu generale");
                System.out.println("reponse: 1");
                reponse = cl.nextLine();
                switch (reponse){
                    case "0" :
                        if (reponse.equalsIgnoreCase("0"))
                            menuArbre1(A1);
                        Menu.clearConsole();
                        Affiche();
                        menuArbre1(A1);
                    case "00":
                        Menu.menuArbre();
                }
                System.out.println("--------------------------------------");
                break;
            case "6":
                System.out.println("-------------------------------------------------------------");
                System.out.println("Les Ascendants d'une personne sélectionnée");
                System.out.println("-------------------------------------------------------------");
                if (p.getPere()==null)
                    System.out.println("Il est l'ancêtre");
                else
                    p.Ascendant();
                System.out.println("--------------------------------------");
                System.out.println("0 - retour");
                System.out.println("00- Menu generale");
                System.out.println("reponse: 1");
                reponse = cl.nextLine();
                switch (reponse){
                    case "0" :
                        if (reponse.equalsIgnoreCase("0"))
                            menuArbre1(A1);
                        Menu.clearConsole();
                        Affiche();
                        menuArbre1(A1);
                    case "00":
                        Menu.menuArbre();
                }
                System.out.println("--------------------------------------");
                break;
            case "7":
                System.out.println("-------------------------------------------------------------");
                System.out.println("Le frère aîné d'une personne sélectionnée");
                System.out.println("-------------------------------------------------------------");
                if (p.getPere()==null)
                    if(p.getPere().getEnfant()==null)
                        System.out.print("il n'a pas de frère ainé");
                else
                    p.getPere().getEnfant().get(0);
                System.out.println("--------------------------------------");
                System.out.println("0 - retour");
                System.out.println("00- Menu generale");
                System.out.println("reponse: 1");
                reponse = cl.nextLine();
                switch (reponse){
                    case "0" :
                        if (reponse.equalsIgnoreCase("0"))
                            menuArbre1(A1);
                        Menu.clearConsole();
                        Affiche();
                        menuArbre1(A1);
                    case "00":
                        Menu.menuArbre();
                }
                System.out.println("-------------------------------------------");
                break;
            case "8":
                System.out.println("-------------------------------------------------------------");
                System.out.println("Continuer l' arbre en créant les enfants d'une personne sélectionnée");
                System.out.println("-------------------------------------------------------------");
                p.CreEnfant();
                A1.membres.addAll(p.getEnfant());
                A1.Serialiser();
                System.out.println("--------------------------------------");
                System.out.println("0 - retour");
                System.out.println("00- Menu generale");
                System.out.println("reponse: 1");
                reponse = cl.nextLine();
                switch (reponse){
                    case "0" :
                        if (reponse.equalsIgnoreCase("0"))
                            menuArbre1(A1);
                        Menu.clearConsole();
                        Affiche();
                        menuArbre1(A1);
                    case "00":
                        Menu.menuArbre();
                }
                System.out.println("--------------------------------------");
                break;
            case "0":
                Menu.clearConsole();
                Menu.menuArbre();
                break;
        }
    }

}


}
