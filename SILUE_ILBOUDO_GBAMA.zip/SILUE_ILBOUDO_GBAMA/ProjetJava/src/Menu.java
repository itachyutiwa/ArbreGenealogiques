import java.io.IOException;
import java.util.LinkedList;
import java.util.*;
import java.util.Scanner;

public class Menu {
    public final static void clearConsole(){
        //Clears Screen in java
        try {
            if (System.getProperty("os.name").contains("Windows"))
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
                Runtime.getRuntime().exec("clear");
        } catch (IOException | InterruptedException ex) {}


    }
    public static void menuArbre(){
        Scanner cl=new Scanner(System.in);
        System.out.println("-------------------------------------------------------------------");
        System.out.println("|      BIENVENUE DANS LE MENU GENERAL DE VOTRE APPLICATION       |");
        System.out.println("|                D'ARBRE GENEALOGIQUE SIMPLIFIE                   |");
        System.out.println("-------------------------------------------------------------------");


        System.out.print("1 - ARBRE EXISTANT\n");
        System.out.print("2 - CREER ARBRE\n");
        System.out.print("3 - QUITTER\n");
        System.out.print("Votre choix d'option est: ");

        String choix = cl.nextLine();
        System.out.println("-------------------------------------------------------------------");
        Arbre A1 = Arbre.Deserialiser();
        Person p;
        switch(choix){
            case "1":
              Arbre.menuArbre1(A1);
              break;
            case "2" :
                A1.Creer();
                break;
            case "3" :
                break;
        }
    }
    public static void main(String[] args) {

        menuArbre();
    }
}



