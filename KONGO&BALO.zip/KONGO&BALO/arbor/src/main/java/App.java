import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Scanner;

public class App {
    public static String input(String text) {
        /*
         * Description:
         *      _
         *
         * argument:
         *      _
         *
         *  retour:
         *      _
         */
        System.out.print(text);
        Scanner sc = new Scanner(System.in);
        return sc.nextLine();
    }

    public static void print(String str) {
        /*
         * Description:
         *      _
         *
         * argument:
         *      _
         *
         *  retour:
         *      _
         */
        System.out.print(str);
    }

    public static void println(String str) {
        /*
         * Description:
         *      _
         *
         * argument:
         *      _
         *
         *  retour:
         *      _
         */
        System.out.println(str);
    }

    public static void error(String str) {
        /*
         * Description:
         *      _
         *
         * argument:
         *      _
         *
         *  retour:
         *      _
         */
        System.err.println("\n" + str);
    }

    public static void println(Personne p) {
        System.out.println(p);
    }

    public static Integer choice(String text, int min, int max) {
        System.out.print(text);
        Scanner sc = new Scanner(System.in);
        try {
            int i = Integer.valueOf(sc.nextLine());
            if (i >= min && i <= max) {
                return i;
            } else {
                error("Vous devez entrer un entier compris entre " + min + " et " + max);
                return  choice(text, min, max);
            }
        } catch (Exception e) {
            println("\n\nVous devez entrer un entier compris entre " + min + " et " + max);
            return  choice(text, min, max);
        }
    }

    public static  void m_one_personne(Personne p, Personne racine) {
        clear_console();
        int choice = choice("Que souhaitez-vous faire concernant " + p.nom + " " + p.prenoms + " [ " + p.get_id() + " ]?\n" +
                "(1) Voir son parent,\n" +
                "(2) Voir son ascendance,\n" +
                "(3) Voir la liste de ses enfants,\n" +
                "(4) Voir sa descendance entière(arbre dont il est le sommet),\n" +
                "(5) Voir la liste de ses cousins,\n" +
                "(6) Voir la liste de ses frères,\n" +
                "(7) Editer sa descendance\n" +
                "(8) Editer son ainé\n" +
                "(9) Retour au menu précédent\n" +
                "(10) Fermer l'application\n" +
                "Entrer votre réponse: ", 1, 10);
        switch (choice) {
            case 1:
                clear_console();
                println("Le parent de " + p.nom + " " + p.prenoms + " [ " + p.get_id() + " ] est " + p.parent.nom + " " + p.parent.prenoms + " [ " + p.parent.get_id() + " ]");
                break;
            case 2:
                clear_console();
                println(p.nom + " " + p.prenoms + " [ " + p.get_id() + " ] a pour asendance: ");
                p.affichage_ascendent();
                break;
            case 3:
                clear_console();
                p.affichage_enfant();
                break;
            case 4:
                clear_console();
                p.affiche_descendance();
                break;
            case 5:
                clear_console();
                p.affichage_cousin();
                break;
            case 6:
                clear_console();
                p.affiche_frere();
                break;
            case 7:
                clear_console();
                p.edition_enfant();
                break;
            case 8:
                clear_console();
                p.edition_frere_aine();
                break;
            case 9:
                m_select_one_personne(racine);
                break;
            case 10:
                System.exit(0);
            default:
                error("Choix indisponile, veuillez ressayer.");
                m_one_personne(p,racine);
                break;
        }
        if(input("Retour sur le menu de cette personne? (O: oui, N: non)\n\t Entrer votre réponse: ").toLowerCase().equals("o")) {
            m_one_personne(p, racine);
        } else {
            m_select_one_personne(racine);
        }
    }

    public static void m_select_one_personne(Personne racine) {
        clear_console();
        racine.affiche_descendance();
        String id_selected = input("Entrer l'ID de la personne sur laquelle vous souhaitez effectuer une action: ");
        Personne p_selected = racine.search(id_selected);
        if (p_selected == null) {
            if (input("ID inexistant, voulez-vous ressayer?(O: oui, N: non): ").toLowerCase().equals("o"))
                m_select_one_personne(racine);
            else
                m_one_tree(racine);
        } else {
            m_one_personne(p_selected, racine);
        }
    }

    public static void m_one_tree(Personne racine) {
        clear_console();
        racine.affiche_descendance();
        int choice = choice("Quelle action voulez-vous effectuer sur cet arbre?\n" +
                "(1) Affichage de l'arbre,\n" +
                "(2) Effectuer une action sur une personne de l'arbre,\n" +
                "(3) Supprimer l'arbre,\n" +
                "(4) Retour au menu précédent\n" +
                "(5) Fermer l'application\n" +
                "\tEntrer votre réponse: ", 1, 5);
        switch (choice) {
            case 1:
                clear_console();
                racine.affiche_descendance();
                int choice2 = -1;
                do {
                    choice2 = choice("\n" +
                            "(1) retour au menu de l'arbre\n" +
                            "(2) menu principal\n" +
                            "(3) Fermer l'application\n" +
                            "\tEntrer votre reponse: ", 1, 3);
                    switch (choice2) {
                        case 1:
                            m_one_tree(racine);
                            break;
                        case 2:
                            m_accueil();
                            break;
                        case 3:
                            System.exit(0);
                            break;
                        default:
                            println("Choix indisponible");
                            break;
                    }
                } while (choice2 < 1 || choice2 > 3);
                break;
            case 2:
                m_select_one_personne(racine);
                break;
            case 3:
                racine.delete_tree();
                m_list_tree();
                break;
            case 4:
                m_list_tree();
            case 5:
                System.exit(0);
            default:
                error("Choix indisponible.");
                m_one_tree(racine);
                break;
        }
    }

    public static void m_create_tree() {
        clear_console();
        Personne n_tree = new Personne();
        n_tree.creation_arbre(n_tree);
        println("L'arbre que vous venez de créer est le suivant:");
        n_tree.affiche_descendance();
        String save_n_tree = input("Voulez-vous le sauvegarder?(O: oui, N: non) ");
        if (save_n_tree.toLowerCase().equals("o")) {
            Personne.save_in_file(n_tree);
            clear_console();
            println("Sauvegarge effectuée avec succès.");
            if(input("Voulez-vous travailler sur cet arbre? (O: oui, N: non)\n\t Entrer votre réponse: ").toLowerCase().equals("o")) {
                m_one_tree(n_tree);
            } else {
                m_accueil();
            }
        } else {
            println("Vous avez refusez de sauvegarder votre nouvel arbre.");
            m_accueil();
        }
    }

    public static void m_list_tree() {
        clear_console();
        File repertoire = new File("data/");
        LinkedList<String> id_list = new LinkedList<String>();
        LinkedList<String> name_list = new LinkedList<String>();
        boolean exist_tree = false;
        for(File f: repertoire.listFiles()){
            exist_tree = true;
            String str[] = f.getName().split("[.]")[0].split("[_]");
            println("[ " + str[0] + " ] " + str[1]);
            id_list.add(str[0]);
            name_list.add("_" + str[1]);
        }

        if (exist_tree) {
            String view_tree = input("Entrer l'identifiant de l'arbre que vous souhaitez afficher: ");
            int index_selected = id_list.indexOf(view_tree);
            if (index_selected < 0) {
                error("\n\nCe id est inexistant.");
                if(input("Voulez-vous réessayer? (O: oui, N: non)\n\t Entrer votre réponse: ").toLowerCase().equals("o")) {
                    m_list_tree();
                } else {
                    m_accueil();
                }
            } else {
                Personne get_tree = Personne.get_from_file(id_list.get(index_selected) + name_list.get(index_selected));
                println("\nL'arbre selectionné est celui de: " + get_tree.nom + "[ " + get_tree.get_id() + " ]");
                m_one_tree(get_tree);
            }
        } else {
            if(input("Il n'y aucun arbre, voulez-vous en créer un ? (O: oui, N: non)\n\t Entrer votre réponse: ").toLowerCase().equals("o")) {
                m_create_tree();
            } else {
                m_accueil();
            }
        }
    }

    public static void m_accueil() {
        clear_console();
        int choice = choice("Que souhaitez-vous faire?\n" +
                "(1) Créer un nouvel arbre, \n" +
                "(2) Afficher la liste des arbres existants\n" +
                "(3) Fermer l'application\n" +
                "\tEntrer votre réponse: ", 1, 3);
        switch (choice) {
            case 1:
                m_create_tree();
                break;
            case 2:
                m_list_tree();
                break;
            case 3:
                System.exit(0);
            default:
                error("Choix indisponible, veuillez réessayer.");
                m_accueil();
                break;
        }
    }

    public static void main(String[] args) {
        File rep = new File("data/");
        if (!rep.exists() || (rep.exists() && rep.isFile())) { rep.mkdir(); }
        m_accueil();
    }

    public final static void clear_console(){
        try {
            if (System.getProperty("os.name").contains("Windows"))
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
                Runtime.getRuntime().exec("clear");
        } catch (IOException | InterruptedException ex) {}

    }
}