import java.io.*;
import java.nio.file.DirectoryNotEmptyException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Personne implements Serializable {
    private String id = "";
    String nom, prenoms, date_naiss, sexe;
    Personne parent = null;
    LinkedList<Personne> enfant = new LinkedList<>();
    LinkedList<Personne> fratrie = new LinkedList<>();
    private LinkedList<Personne> membres = new LinkedList<>();


    Personne() {
        /*
         * Description:
         *      Constructeur pour créer une personne sans lien à partir d'entrée d'utilisateur
         *
         * argument:
         *      Aucun argument
         *
         *  retour:
         *      Aucun retour
         */

        //App.println("Créer la première personne:");
        generate_id();
        nom = set_nom(App.input("Nom: "));
        prenoms = set_prenoms(App.input("Prénoms: "));
        date_naiss = set_date();
        sexe = set_sexe();
    }

    private Personne creation_pers() {
        /*
         * Description:
         *      Pour créer une personne sans lien
         *
         * argument:
         *      Aucun argument
         *
         *  retour:
         *      Retourne la personne créée
         */
        Personne p = new Personne();
        return p;
    }

    Personne(String nom, String prenoms, String date_naiss, String sexe) {
        /*
         * Description:
         *      Constructeur pour créer une personne sans lien, mais avec des paramètres
         *
         * argument:
         *      nom: nom de la personne
         *      prenoms: prénoms de la personne
         *      date_naiss: date de naissance de la personne
         *      sexe: sexe de la personne
         *
         *  retour:
         *      Aucun retour
         */
        generate_id();
        this.nom = set_nom(nom);
        this.prenoms = set_prenoms(prenoms);
        this.date_naiss = date_naiss;
        this.sexe = sexe;
    }

    private void generate_id() {
        /*
         * Description:
         *      Génère l'id en regardant dans notre dossier data et selectionne le dernier 
         *      fichier puis il obtient l'id généré par ce fichier et l'incremente de 1
         *
         * argument:
         *      Aucun argument
         *
         *  retour:
         *      Aucun retour
         */
        if (parent == null || parent.id == null) {
            id = "1";
            try {
                File rep = new File("data/");
                for(File f: rep.listFiles()){
                    if (f.isFile()) {
                        id = (Integer.parseInt(f.getName().split("[.]")[0].split("[_]")[0]) + 1) + "";
                    }
                }
            } catch(NullPointerException ne){
                App.println("Dossier inexistant: " + ne.getMessage());
                ne.printStackTrace();
            } catch (Exception e) {
                App.println("Erreur: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            if (parent.enfant.size() == 0) {
                id = parent.id + "1";
            } else {
                int len = parent.enfant.getLast().id.length();
                int old_end_id = parent.enfant.getLast().id.charAt(len - 1) - '0'; // conversion du dernier caractère de l'id en int
                String new_end_id = String.valueOf(old_end_id + 1);
                id = parent.id + new_end_id;
            }
        }
    }

    private String set_sexe() {
        /*
         * Description:
         *      permet de saisir le genre d'une personne d'effectuer des vérifications afin de savoir 
         *      si l'on a de bonnes entrées et tant qu'on ne les a pas on redemant à l'utilisateur.
         *
         * argument:
         *      Aucun argument
         *
         *  retour:
         *      retourne la bonne entrée (M ou F)
         */
        String sex;
        do {
            sex = App.input("Genre de la personne (M ou m ou 1: Masculin, F ou f ou 0: féminin): ");
            if (sex.equals("1")) {
                sex = "M";
            } else if (sex.equals("0")) {
                sex = "F";
            }
            sex.toUpperCase();
        } while(!set_sexe(sex));
        return sex;
    }

    private boolean set_sexe(String str) {
        /*
         * Description:
         *      Vérifie si l'on a une bonne entrée pour le genre
         *
         * argument:
         *      str: string qu'on voudrait tester afin de savoir si l'entrée est bonne ou pas
         *
         *  retour:
         *      si l'entrée est bonne on retourne true
         *      sinon false
         */
        if (str.equals("M") || str.equals("m") || str.equals("1") || str.equals("F") || str.equals("f") || str.equals("0")) {
            return true;
        } else {
            App.error("Mauvaise saisie, M ou m ou 1: Masculin, F ou f ou 0: féminin.");
            return false;
        }
    }

    private String set_nom(String str) {
        /*
         * Description:
         *      Transforme le nom en majuscule
         *
         * argument:
         *      str: nom de la personne
         *
         *  retour:
         *      retourne le nom en majuscule
         */
        return str.toUpperCase();
    }

    private String set_prenoms(String str) {
        /*
         * Description:
         *      Transforme le prénom afin que la première lettre soit en majuscule et le reste en miniscule
         *
         * argument:
         *      str: prénom de la personne
         *
         *  retour:
         *      retourne le prénom de sorte à ce qu'il soit bien formaté comme décrit précédement
         */
        if (str.length() > 0)
            return str.substring(0, 1).toUpperCase() + str.substring(1, str.length()).toLowerCase();
        else
            return "";
    }

    private String set_date() {
        /*
         * Description:
         *      Permet d'entrer une année de naissance et tant que le format n'est pas le bon,
         *      on redemande à l'utilisateur d'entrer la date. Pour cela on use d'une expression regulière.
         *
         * argument:
         *      Aucun argument
         *
         *  retour:
         *      retourne la date bien formatée
         */
        String date_ok;
        Pattern pattern = Pattern.compile("[0-9]{4}", Pattern.CASE_INSENSITIVE);
        boolean match = true;
        do {
            date_ok = App.input("Entrer la date de naissance sous le format aaaa(exemple: 2021):");
            Matcher matcher = pattern.matcher(date_ok);
            match = matcher.find();
            if (!match) {
                App.error("Format de date incorrecte, le bon format est aaaa(exemple: 2021).");
            }
        } while(!match);
        return date_ok;
    }

    private boolean set_date(String str) {
        /*
         * Description:
         *      Vérifie si la date passé en paramètre est bien formatée ou pas.
         *
         * argument:
         *      str: date qu'on veut tester
         *
         *  retour:
         *      retourne true si la date est bien formatée
         *      false sinon
         */
        Pattern pattern = Pattern.compile("[0-9]{4}", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(str);
        if (matcher.find()) {
            return true;
        } else {
            App.error("Format de date incorrect(aaaa, exemple: 2021)");
            return false;
        }
    }

    public void ajout_enfant(Personne e) {
        /*
         * Description:
         *      Ajouter un enfant à la liste des enfants d'une personne tout 
         *      en mettant à jour le fait que l'enfant ait pour parent la personne actuelle
         *
         * argument:
         *      e: enfant à ajouter
         *
         *  retour:
         *      Aucun retour
         */
        if (enfant == null)
            enfant = new LinkedList<Personne>();
        e.parent = this;
        e.generate_id();
        enfant.add(e);
        for(int i = 0; i < enfant.size(); i++) {
            Personne frere = enfant.get(i);
            if (frere.fratrie != null)
                frere.fratrie.clear();
            frere.fratrie = new LinkedList<Personne>();
            List<Personne> tab1 = enfant.subList(0, i);
            List<Personne> tab2 = enfant.subList(i+1, enfant.size());
            frere.fratrie.addAll(tab2);
            frere.fratrie.addAll(tab1);
        }
    }

    public void ajout_parent(Personne p) {
        /*
         * Description:
         *      Ajouter une personne en tant que parent en utilisant 'ajout_enfant'
         *
         * argument:
         *      p: parent qu'on voudrait attribuer à la personne
         *
         *  retour:
         *      Aucun retour
         */
        parent = p;
        p.ajout_enfant(this);
    }

    public void affiche_frere () {
        /*
         * Description:
         *      Affiche la liste des frères et soeurs d'une personne en itérant sur ffratrie
         *
         * argument:
         *      Aucun argument
         *
         *  retour:
         *      Aucun retour
         */
        App.print("Liste des frères de " + nom + "[" + id + "]: ");
        for (Personne p: fratrie)
            App.print(p + "-");
    }

    public void affiche_descendance() {
        /*
         * Description:
         *      Permet d'afficher tout les descendants la personne, en utilisant la fonction affichage_arbre
         *
         * argument:
         *      aucun argument
         *
         *  retour:
         *      aucun retour juste l'affichage
         */
        affichage_arbre(this, 1);
    }

    public void edition_frere_aine() {
        /*
         * Description:
         *      Modifier les informations du frère ainé d'une personne, en partant du parent et ensuite il part sur le fils ainé
         *
         * argument:
         *      Aucun argment
         *
         *  retour:
         *      Aucun retour
         */
        if(parent != null) {
            boolean next_step = false;
            Personne aine = parent.enfant.getFirst();
            String ch = App.input("(Si vous ne voulez pas modifier un champs entrer '*')\nEntrer le nouveau nom: ");
            aine.nom = (ch.equals("*"))?aine.nom:ch;
            ch = App.input("Entrer le nouveau prénom: ");
            aine.prenoms = (ch.equals("*"))?aine.prenoms:ch;
            do {
                ch = App.input("Entrer la nouvelle date de naissance: ");
                next_step = (ch.equals("*"))?true:set_date(ch);
            } while(!next_step);
            aine.date_naiss = (ch.equals("*"))?aine.date_naiss:ch;
            do {
                ch = App.input("Entrer la nouvelle date de naissance(M ou m ou 1: Masculin, F ou f ou 0: féminin): ");
                next_step = (ch.equals("*"))?true:set_sexe(ch);
            } while(!next_step);
            aine.sexe = (ch.equals("*"))?aine.sexe:ch;
            App.println("Les données de l' enfant ont été modifié avec succès");

            Personne first_parent = this;
            while(first_parent.parent != null) {
                first_parent = first_parent.parent;
            }
            first_parent.delete_tree();
            Personne.save_in_file(first_parent);

        } else {
            App.error("Cette personne n'a pas de parent et donc pas de frère ainé à notre connaissance.");
        }
    }

    public void edition_enfant() {
        /*
         * Description:
         *      Permet d'effctuer des modifications, des ajouts, des suppressions sur des enfants d'une personne donnée
         *
         * argument:
         *      Aucun argument
         *
         *  retour:
         *      Aucun retour
         */
        String rep = App.input("\nComment voulez-vous editer les enfants de " + nom + "[" + id + "] ?\n(1) Ajouter un enfant, \n(2) Supprimer un enfant, \n(3) modifier les informations d'un enfant, (4) annuler\n\tEntrer votre réponse: ");
        if (rep.equals("1")) {
            // ajouter un nouvel enfant
            Personne e = creation_pers();
            creation_arbre(e);
            e.ajout_parent(this);
        } else if (rep.equals("2") || rep.equals("3")) {
            // modifier les informations d'un enfant
            App.println("\nListe des enfants de " + nom + "[" + id + "]: ");
            LinkedList<String> id_list = new LinkedList<String>();
            for (Personne e: enfant) {
                App.println(e.nom + "[" + e.id + "]");
                id_list.add(e.id);
            }

            if (rep.equals("2")) {
                String id_e = App.input("\nSélectionner l'enfant que vous-voulez supprimer en entrant son id:");
                int i = id_list.indexOf(id_e);
                if (i >= 0) {
                    LinkedList<Personne> new_enfant = new LinkedList<Personne>();
                    for (Personne e: enfant) {
                        if (!e.id.equals(id_e)) {
                            e.fratrie = new LinkedList<Personne>();
                            new_enfant.add(e);
                        }
                    }

                    enfant = new LinkedList<Personne>();
                    for (Personne e: new_enfant) {
                        ajout_enfant(e);
                    }
                    App.print("Enfant supprimé avec succès, ");
                    affichage_enfant();

                } else {
                    App.println("Cette id est inexistant");
                }
            } else {
                String id_e = App.input("\nSélectionner l'enfant dont vous-voulez modifier les informations en entrant son id:");
                int i = id_list.indexOf(id_e);
                if (i >= 0) {
                    boolean next_step = false;
                    Personne enf_upd = enfant.get(i);
                    String ch = App.input("(Si vous ne voulez pas modifier un champs entrer '*')\nEntrer le nouveau nom: ");
                    enf_upd.nom = (ch.equals("*"))?enf_upd.nom:ch;
                    ch = App.input("Entrer le nouveau prénom: ");
                    enf_upd.prenoms = (ch.equals("*"))?enf_upd.prenoms:ch;
                    do {
                        ch = App.input("Entrer la nouvelle date de naissance: ");
                        next_step = (ch.equals("*"))?true:set_date(ch);
                    } while(!next_step);
                    enf_upd.date_naiss = (ch.equals("*"))?enf_upd.date_naiss:ch;
                    do {
                        ch = App.input("Entrer la nouvelle date de naissance(M ou m ou 1: Masculin, F ou f ou 0: féminin): ");
                        next_step = (ch.equals("*"))?true:set_sexe(ch);
                    } while(!next_step);
                    enf_upd.sexe = (ch.equals("*"))?enf_upd.sexe:ch;
                    App.println("Les données de l' enfant ont été modifié avec succès");

                } else {
                    App.println("Cette id est inexistant");
                }
            }
        } else if (rep.equals("4")) {
            // on ne fait rien
        } else {
            App.println("Votre entrée est invalide.");
            edition_enfant();
        }
        Personne first_parent = this;
        while(first_parent.parent != null) {
            first_parent = first_parent.parent;
        }
        first_parent.delete_tree();
        Personne.save_in_file(first_parent);
    }

    private void affichage_arbre(Personne p, Integer n) {
        /*
         * Description:
         *      Afficher les enfants de la personne passé en paramètre et cela se fait récursivement(on affichera les enfants des enfants)
         *      cette fonction sera utilisé uniquement par la fonction 'affichage_descendant'.
         *
         * argument:
         *      p: personne dont on veut afficher les enfants
         *      n: niveau en partant de 'p', ses enfants directes constituent le niveau 1, ses petits enfants le niveau 2, etc
         *          cela permettra de gérer la tabulation pour l'affichage.
         *
         *  retour:
         *      Aucun retour
         */
        App.println(p);
        for(int i = 0; i < p.enfant.size(); i++) {
            for(int j = 0; j < n; j++)
                System.out.print("\t");
            affichage_arbre(p.enfant.get((i)), n+1);
        }
    }

    public void creation_arbre(Personne p) {
        /*
         * Description:
         *      Crée de nouvelles personnes qu'on ajoute à la personne passée en paramètre
         *      On demande pour la première personne combien d'enfant est-ce que cette personne a, ensuite on boucle sur ce nombre
         *      afin de créer ses enfants et pour ces enfants on faire le même processus.
         *      et ce procédé est fait recursivement
         *
         * argument:
         *      Reçoit une personne en paramètre à qui on ajoutera les nouveaux individus qu'on créera
         *
         *  retour:
         *      Aucun retour
         */
        try {
            int nb_enfant = Integer.parseInt(App.input("Le nombre d'enfant de " + p.nom + " " + p.prenoms + "[" + p.id + "]: "));
            LinkedList<Integer> nb_enfant_enfant = new LinkedList<Integer>();
            for (int i = 0; i < nb_enfant; i++) {
                App.println("\nEnfant numéro " + (i + 1) + " de " + p.nom + " " + p.prenoms + "[" + p.id + "]: ");
                Personne e = creation_pers();
                p.ajout_enfant(e);
            }

            for (int i = 0; i < p.enfant.size(); i++)
                creation_arbre(p.enfant.get(i));

        } catch (Exception e) {
            App.error("Entrer un entier supérieur ou égal à 0.");
            creation_arbre(p);
        }
    }

    public void affichage_cousin() {
        /*
         * Description:
         *      Affiche la liste des cousins en partant des frères du parents
         *
         * argument:
         *      Aucun argument
         *
         *  retour:
         *      Aucun retour
         */
        App.println("Liste des cousins de "+ nom + "[" + id + "]: ");
        boolean cousin = false;
        for(Personne f: parent.fratrie) {
            for(Personne e: f.enfant) {
                cousin = true;
                App.println(e);
            }
        }

        if (!cousin)  {
            App.println(nom + "[" + id + "] n'a aucun cousin.");
        }
    }

    public void affichage_enfant() {
        /*
         * Description:
         *      Affiche la liste des enfants
         *
         * argument:
         *      Aucun argument
         *
         *  retour:
         *      Aucun retour
         */
        if (enfant.size() == 0) {
            App.println(nom + "[ " + id + " ] n'a aucun enfant.");
        } else {
            App.println("Liste des enfants de " + nom + "[ " + id + " ]:");
            for (Personne e: enfant) {
                App.println(e);
            }
        }
    }

    private void affichage_ascendent(int n) {
        /*
         * Description:
         *      Permet d'afficher les ascendants d'une personne, sauf qu'ici on met un paramètre qui permettra de savoir s'il
         *      s'agit du père, du grand-père...
         *
         * argument:
         *      Le 'n' correspond au niveau et permet de savoir qui est au dessus, 
         *      le niveau 1: père
         *      le niveau 2: le grand-père
         *      le niveau 3: l'arrière grand-père 
         *      au dela de 3 niveau on suppose que c'est un ancêtre
         *
         *  retour:
         *      Aucun retour
         */
        Personne p = parent;
        if(p != null) {
            switch (n) {
                case 1:
                    App.print("\tPère ou mère:");
                    break;
                case 2:
                    App.print("\tGrand-père ou grande mère:");
                    break;
                case 3:
                    App.print("\tArrière grand-père ou arrière grande mère:");
                    break;
                default:
                    App.print("\tAncêtre:");
                    break;
            }
            App.println(p);
            p.affichage_ascendent(n+1);
        }
    }
    public void affichage_ascendent() {
        /*
         * Description:
         *      Permet d'afficher tout les ascendants la personne
         *
         * argument:
         *      aucun argument
         *
         *  retour:
         *      aucun retour juste l'affichage
         */
        App.println("Ascendance de " + nom + " " + prenoms + "[ " + get_id() + " ]: ");
        affichage_ascendent(1);
    }

    private void all_members(Personne p) {
        /*
         * Description:
         *      Parcours l'arbre et stocke dans l'attribut 'membres' toutes les personnes de l'arbre
         *      Toutefois cela se fait en partant de la personne passée en paramètre, en gros ses descendant
         *
         * argument:
         *      Un objet de type personne
         *
         *  retour:
         *      aucun retour mais les éléments sont stockés dans l'attribut 'membres' de Personne
         */
        membres.add(p);
        for(Personne e: p.enfant) {
            all_members(e);
        }
    }

    public Personne search(String idt) {
        /*
         * Description:
         *      Permet de rechercher une personne à partir de son id
         *
         * argument:
         *      l'id de la personne que l'on recherche
         *
         *  retour:
         *      un objet de type personne qui sera la personne possédant l'id passé en paramètre
         */
        Personne searched = null;
        all_members(this);
        for (Personne m: membres) {
            if (m.id.equals(idt))
                searched = m;
        }
        return searched;
    }

    public String get_id() {
        /*
         * Description:
         *      retourne juste l'id vu qu'il est privé
         *
         * argument:
         *      aucun argument
         *
         *  retour:
         *      l'id de la personne
         */
        return id;
    }

    public String toString() {
        /*
         * Description:
         *      Elle permettra d'afficher un objet de type personne directement lorsqu'on fera un print
         *
         * argument:
         *      aucun argument
         *
         *  retour:
         *      elle retourne un string qui contient les infos d'une personne
         */
        return "[ " + id + " ] " + nom + " " + prenoms + ", " + sexe + ", " + date_naiss;
    }

    public static void save_in_file(Personne p) {
        /*
         * Description:
         *      Cette fonction permet de sauvegarder un arbre en usant de la racine de ce dernier.
         *      Elle permet donc de sérialiser un objet de type Personne.
         *
         * argument:
         *      elle reçoit en argument la racine d'un arbre
         *
         *  retour:
         *      elle ne retourne rien
         */
        try {
            FileOutputStream fos = new FileOutputStream("data/" + p.get_id() + "_" + p.nom + ".dat");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(p);
            oos.close();
            fos.close();
        } catch (Exception e) {
            App.println("Erreur: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static Personne get_from_file(String file_name) {
        /*
         * Description
         *      Cette fonction permet de recupérer les données sur un arbre à partir de son nom de fichier.
         *      Pour faire simple, elle prend les données et les déserialise
         *
         * argument:
         *      filename: nom de l'arbre ou nom du fichier sans l'extension, 
         *          composé de l'id et du nom de la racine de l'arbre(1ere personne)
         *
         * retour:
         *      elle retourne l'arbre entier s'il existe 
         *      sinon elle retourne null en affichant le soucis
         */
        try {
            FileInputStream fis = new FileInputStream("data/" + file_name + ".dat");
            ObjectInputStream ois = new ObjectInputStream(fis);
            Personne p = (Personne) ois.readObject();
            ois.close();
            fis.close();
            return p;
        } catch (Exception e) {
            App.println("Erreur: " + e.getMessage());
            e.printStackTrace();
            return  null;
        }
    }

    public boolean delete_tree() {
        /*
         * Description:
         *      Fonction permettant de supprimer un arbre, à partir de son identifiant et de son nom,
         *      elle ne peut s'appliquer que sur la racine de l'arbre sinon c'est inutile de le faire car cela
         *      enverra juste une erreur qui n'empêchera pas le programme de fonctionner.
         *
         * argument:
         *      aucun argument
         *
         * retour:
         *      elle retourne true si la suppression est bonne 
         *      sinon false
         */
        String path = "data/" + get_id() + "_" + nom + ".dat";
        File file = new File(path);
        try {
            Files.delete(Paths.get(path));
            //App.println("Arbre supprimé avec succès.");
            return true;
        } catch (NoSuchFileException x) {
            App.error(path + " chemin introuvable");
            return false;
        } catch (DirectoryNotEmptyException x) {
            App.error(path + " n'est pas vide");
            return false;
        } catch (IOException x) {
            // problèmes de permission
            App.error(x.getMessage());
            return false;
        }
    }

}